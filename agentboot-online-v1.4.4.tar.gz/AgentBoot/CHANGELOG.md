# 更新日志

## v1.4.4 (2026-10-29)

- 修复 npm 安装超时清理的 killpg(0) 自杀式信号缺陷：子进程组为 0、不存在或与当前进程同组时绝不 killpg，退化为单进程 kill——此前会在超时清理时挂死自身进程组（test_deep_polish 实测挂死 45 秒以上无法终止）。
- 修复 CI 全红连锁：自 v1.4.0 引入 npm 超时保护起，`test_agent_hardening` 在 Linux runner 上必失败（断言了 Windows 专属的 taskkill 路径）、`test_deep_polish` 挂死，导致 deploy-pages / release-pipeline / release-pr 全部无法完成；现全量 253 个测试 8.9 秒跑绿。
- 修复 core/agent.py darwin 分支两处 `subprocess.run` 缺少 import（pyflakes F821）：macOS 上内存总量与 CPU 型号查询此前被 except 静默吞掉，`ab sys` / `ab doctor` 信息不全。
- 修复镜像损坏不回退：华为云镜像的 `python-3.12.10-embed-amd64.zip` 实测为截断坏包（sha `1940ea1a…` vs python.org 官方 `4acbed6d…`，BadZipFile）。build-offline.sh / build-offline.ps1 / install.ps1 全部改为逐源校验下载（fetch_verified / Get-UrlVerified / Ensure-NodeArchive），损坏源自动切换官方源——此前离线包构建必败、无 Python 的 Windows 一键安装必败。
- CoCo 离线发行包 0.8.0 → 0.8.1（官方 sidecar 校验通过），版本号收敛到 `agents/registry.json` 的 `coco_version` 单一来源，构建期即校验发行包完整性。
- Node 运行时与 CoCo 载荷下载同样改为逐源校验（npmmirror → nodejs.org），本地缓存命中时先验 sha；npm 载荷安装失败时清掉用户级 npm 配置（失效代理）重试一次。
- 修复自托管 runner 上 deploy-pages 第二次运行必败的问题：`_work` 目录跨运行复用导致遗留的 gh-pages worktree 让 `git worktree add` 报 `already exists`（exit 128），发布前先清理注册与目录。
- CI 架构改为全自托管：注册仓库级 self-hosted Linux runner（LEC-Dev-agentboot，systemd 服务），deploy-pages / release-pr / publish-pages / release-pipeline 的 Linux 作业全部 `runs-on: self-hosted`；Windows/macOS 平台作业移入仅手动触发的 release-platforms.yml（本机无法执行，避免 publish 永远等待要排队数小时的 GitHub-hosted runner）。
- 交互入口（agentboot 菜单 / ab）stdin 关闭或管道输入时干净退出，不再抛 EOFError traceback。
- `agentboot doctor` 的安装状态改用归属判定（AgentBoot 管理 / 旧版残留 / 外部安装），不再把系统里的同名命令误标为已安装。
- 工程清理：tests/test_release_workflow.py 去除 UTF-8 BOM（全库唯一）；verify-live-release.py 删除未用导入；pages 下 6 个 .sha256 sidecar 统一 LF 行尾，消除每次构建的伪 diff。
- 新增回归测试 tests/test_release_hardening.py（9 个）：镜像损坏逐源回退（真实执行 fetch_verified）、CoCo 版本单一来源、stdin EOF 干净退出。

## v1.4.3 (2026-09-14)

- 深度完善：镜像模式（auto / cn / off）持久化到 `~/.agentboot/env.json`——`agentboot mirror cn|off` 重启后依然生效，不再只对当前会话有效；菜单「镜像代理」新增模式切换子项；环境变量 `AGENTBOOT_MIRROR` 仍可临时覆盖。
- 极限优化：`env.json` 读取按 mtime 缓存——`cn_mode / gh_mirrors / npm_registry` 等高频调用不再反复读盘；返回值改为拷贝，杜绝调用方误改写回缓存。
- 安装体验：npm 安装期间每 15 秒显示一次已耗时（`--progress=false` 全程静默时不再像卡死），结束后自动清除。
- 环境体检（`ab doctor`）新增本机硬件摘要行（系统 / 核数 / 内存），完整配置仍用 `ab sys`。
- 站点镜像（gh-pages）404 页资源路径改写为自包含（`/AgentBoot/assets/`），`ide.pub` 失效后镜像站样式不再丢失。

## v1.4.2 (2026-09-13)

- 内置 Agent（ab）新增机器配置查询：`sys_info` 工具报告主机名 / 操作系统与版本 / CPU 型号与核数 / 内存总量与可用 / 各磁盘容量 / Python 与 AgentBoot 版本，Windows（注册表 + GlobalMemoryStatusEx）/ Linux（/proc）/ macOS（sysctl）全平台标准库实现，离线零依赖；对话里问「这台机器什么配置」直接可答，另提供 `ab sys` 一键命令与交互内 `/sys` 命令。
- 镜像多源化：npm 源支持 npmmirror（阿里）/ 腾讯云 / 华为云 / 官方源切换，npm 安装命令自动使用所选源；Node 运行时下载新增华为云、腾讯云二进制镜像（含 SHASUMS256 校验文件，官方源始终兜底）。
- GitHub 加速可切换：gh-proxy.com / ghfast.top / ghproxy.net 三源自动探测选路（可达优先、其余兜底），支持固定指定加速源或关闭直连；脚本安装、uv 预置下载、hermes git 重写、uv-python 安装镜像全部接入统一选路。
- 镜像选择持久化到 `~/.agentboot/env.json`：控制台菜单「镜像代理」新增 npm 源切换与 GitHub 加速切换子菜单（带连通性探测与当前项标记）；CLI 新增 `agentboot mirror npm [源URL]` 与 `agentboot mirror gh [auto|off|前缀URL]`。
- CoCo 官方安装脚本 GitHub 加速源清单同步补全（ghproxy.net）。

## v1.4.1 (2026-09-13)

- 内置 Agent（ab）实时显示思考过程：支持 `reasoning_content` 独立通道与正文内联 `<think>…</think>` 标记（含跨分块截断），思考文本暗色渲染、与正文区分；个别把答案全放思考通道的模型按正文兜底，不再误报空响应。
- 内置 Agent 新增首包等待指示器：模型响应前显示「⏳ 正在思考 Ns」行内动画，首个思考/正文 token 到达即清除，等待时间一目了然（仅交互式终端，Windows 自动启用 VT 序列）。
- CoCo 安装提速（coco 仓库官方脚本）：Node 运行时改走 npmmirror 镜像、发行包与 Agnes 密钥支持 gh-proxy/ghfast 加速，自动探测网络选路，可用 `COCO_MIRROR=off` 强制直连、`COCO_NODE_DIST_BASE`/`COCO_RELEASE_MIRRORS` 覆盖；全部镜像互为兜底且保留 SHA-256 校验。
- AgentBoot 脚本类安装（script 方法）新增 jsDelivr 兜底源：GitHub Pages 不可达或自定义域名过期时，自动改从 `cdn.jsdelivr.net/gh/<user>/<repo>@gh-pages/…` 获取安装脚本。
- CoCo 离线安装解压提速：优先使用系统 tar（C 实现，含 `--force-local`/cwd 兼容处理）替代 Python gzip 解压，越界校验保持不变，失败自动回退原实现。
- 安装器下载兜底从三源扩为四源（Worker → Pages → jsDelivr 镜像 → GitHub Release）；主页新增 Releases 终极安装入口（不依赖任何自定义域名）。

## v1.4.0 (2026-09-12)

- 新增 FreeBuff（`freebuff`，freebuff.com）为第 16 个内置 Agent：免费、广告支持、无需 API Key；npm 轻量启动器，首次运行联网获取平台原生二进制，暂仅在线安装。
- 文档、双语主页与 Agent 数量口径同步更新为 16；文档一致性测试同步锁定注册表与页面行数。
- 修复 TUI 字符画字形错乱：`agent.py` 与 `menu.py` 顶部 ASCII 艺术统一替换为经校验的标准字形，正确显示 AgentBoot。
- 修复 Windows 安装 Agent 后新终端不可用的问题：用户 PATH 注册表目标补齐 npm prefix 等目录，并在写入后广播 `WM_SETTINGCHANGE`，资源管理器即时重载环境变量，无需注销/切换用户。
- 极限优化冷启动：`agent.py` 全面惰性化 `ctypes / tempfile / socket / ipaddress / json` 导入；`ab version / linux / help` 走零配置路径（不加载模型配置）；Windows 控制台模式修复仅在真实 TTY 下执行 `ctypes`。实测一次性命令与菜单就绪提速约 40%+。
- 知识库索引持久化：首次构建后以 marshal 缓存到 `~/.agentboot/kb-index.cache`，按「文件名+大小+mtime」指纹失效；仅对随包内置知识库落盘，后续冷查询免重建。
- 模型接口 429 限流纳入自动重试并尊重 `Retry-After`（上限 10s），与 5xx 同等处理，提升免费额度下的稳定性。
- 环境体检与镜像状态的网络探测并行化：doctor 三项探测由串行累加变为并发（最差 6s → 2s）。
- 修复 `search_files` 非正则模式下从不匹配文件名的问题（与工具描述一致），并清理 `linux_help` 无匹配分支的死代码。
- 性能基准脚本支持 Windows（假工具链按平台生成 .cmd），安装项看门狗放宽至 60s 以消除杀软首扫抖动。
- 修复 `deploy-pages` 工作流一致性测试的过时断言（工作流已改为 gh-pages 发布，测试同步校验 SHA 钉版 checkout 与凭据丢弃）。
- 修复测试套件在 Windows 上的两类密封性问题：`expanduser` 优先读 `USERPROFILE` 导致 CoCo/Cursor 测试写真实主目录；离线安装成功用例未 patch `AGENTS_DIR` 导致载荷落进真实 `~/.agentboot`。POSIX 专属测试在 Windows 明确跳过，套件跨平台全绿。
- 新增 `publish-pages` 应急工作流（仅手动派发，直接把 gh-pages 分支以 artifact 形式发布到 Pages 服务层，绕开经典构建队列；默认托管 runner，自建 runner 可选）。
- 主页与文档新增 GitHub Pages 冗余一键脚本（`bit-cook.github.io/AgentBoot/install.sh` / `install.ps1`）：`ide.pub` 域名不可用或过期时的备用入口，与主入口同源发布。
- 备用源路径大小写均可：站点部署时自动生成 `/agentboot/` 小写别名目录（与 `/AgentBoot/` 内容一致，标记 noindex），小写输入不再 404。
- 安装器下载兜底从三源扩为四源（Worker → Pages → jsDelivr 镜像 → GitHub Release）：jsDelivr（gh-pages 分支镜像）不依赖任何自定义域名，国内通常更可达。
- 主页与文档新增 GitHub Releases 终极兜底一键入口（`releases/latest/download/install.sh`）：`ide.pub` 与 `osome.work` 等全部域名过期时仍可安装；文档补充「自定义域名失效 → 移除 Pages 自定义域名恢复 github.io 直出」的维护预案。
- 修复 gh-pages 分支的陈旧内容：根目录补齐 v1.4.0 安装包与 .sha256（此前 Pages 兜底链取包会 404），入口 install.sh / install.ps1 由 v1.3.0 更新为 v1.4.0。

## v1.3.0 (2026-08-31)

- 新增 Cursor 官方跨平台用户级安装：Linux AppImage 固定 SHA-256，Windows Authenticode，macOS codesign + notarization 校验。
- Cursor 安装在 AgentBoot 私有应用目录，具备原子升级、归属 marker、安全卸载与外部安装保护。
- OpenCode 固定 `opencode-ai@1.18.25`，离线包携带官方平台 native binary；x64 同时提供 regular 与 baseline 兼容版本。
- OpenCode 目标机根据 `--version` 实测选择可运行 binary，不执行联网 postinstall，卸载保留模型配置。
- OpenCode-only 离线包不再捆绑不需要的 Node 运行时，降低体积。
- 新增 Linux、Windows、Intel macOS、Apple Silicon 的 OpenCode 离线生命周期与 Cursor 官方安装 CI 门禁。

## v1.2.0 (2026-08-31)

- 全面重构中英文主页：亮色乐观视觉、桌面/手机自适应、可访问性、品牌 404 与单一 canonical。
- Pages 成为唯一网页源，Worker 自动生成同源资源；HTML 短缓存、版本化静态资源 immutable 缓存与 ETag 304。
- `agentboot` 延迟加载 HTTP/SSL 网络栈与安装专用模块，控制台冷启动显著缩短。
- 新增轻量 `launch.py`，让命令入口复用 Python 字节码缓存；频繁启动菜单实测降低约 34.6%。
- 多 Agent 安装按相同 Node 约束合并 npm 解析与连接，失败自动回退逐个安装；批次内复用 Node、镜像和环境探测。
- npm 安装优先本地缓存并关闭进度与冗余日志；在线安装器移除重复体检，POSIX 安装约减少一次 2 秒级网络检查。
- 内置 Agent 使用紧凑请求 JSON，并在断线重连时复用 TLSContext；保持 TLS 校验、代理与流式安全边界。
- 新增确定性性能基准，覆盖启动、内置 Agent 本地请求、安装调度与主页关键资源，所有实验保留/回退可审计。

## v1.1.0 (2026-08-30)

- 新增 Agent 安全卸载：菜单 `[9]`、`agentboot uninstall <id>`、批量卸载与 CoCo `--purge`。
- 新增原子安装归属清单，区分 AgentBoot 管理安装与系统同名命令；兼容可证明归属的 v1 遗留安装。
- 在线、离线、CoCo 与自定义 Agent 安装成功后统一记录来源、包名、命令与安装前缀。
- 新增固定卸载验收、安装追踪集成测试、Python 编译门禁和确定性在线包构建。
- Pages 工作流在核心代码变化时自动测试并重建在线 tar/zip，避免源码与实际下载包脱节。
- `ab` 命令链按每个子命令判定风险，`safe` 真正只读，非交互 `smart` 不再静默放行写操作。
- Node 便携运行时升级到 22.23.2，按 Agent 精确校验最低版本；修复 Windows/ARM/macOS 离线平台映射。
- 在线包新增 SHA-256 旁车校验和原子升级回滚；构建器以临时文件原子发布且结果可复现。
- 自定义脚本仅允许 HTTPS，下载到临时文件后以固定参数执行，消除 URL shell 注入；脚本上限 4 MiB。
- 修正 `ab bench` 首字延迟计时、全部 60 个 Linux 知识库段落索引、`ab` 子命令包装器和 CoCo 数据备份恢复。
- 离线包新增目标机逐文件 SHA-256 校验，`--all` 仅安装包内 MANIFEST 实际列出的 Agent；构建缺载荷会硬失败。
- 修复 Windows CMD shim 百分号格式、npm 真实入口解析和便携 Node 路径，Linux/Windows 均通过原生安装→启动→卸载矩阵。
- Worker 支持 Range/If-Range 与真实资产健康探测；发布采用 prerelease→Pages/Worker live verify→Latest 的协调状态机。
- 修正 Node engine 范围、离线资产名、相对链接、vLLM 文案、移动端表格溢出、触摸目标和旧性能固定数字。
- 安全模式改为可信系统路径的固定 argv 执行，禁止 shell grammar、路径伪装与未知确认策略放行。
- 截断/畸形 SSE 不再产生可执行工具调用；模型密钥仅发送到 HTTPS，网页工具默认拒绝内网/元数据地址。
- 配置与会话使用 0700/0600 原子持久化，命令超时终止整个进程树，安装状态更新加入跨进程锁。
- CoCo 卸载拒绝 symlink 根目录，私有 Node 在最终目录部署；Hermes uv、Node 与 Python 载荷完整校验。
- Release/Pages Actions 固定 commit、最小权限、显式源码清单；离线 Agent 更新与应用/launcher 事务支持回滚。
- Aider 改为 AgentBoot 私有 venv 安装；OpenCode 暂停离线声明，npm 离线入口按 JS/native/CMD 类型执行。
- Agent配置、代理、会话和安装清单改为私密原子持久化；并发安装状态加锁，命令超时终止整棵进程树。
- 在线/离线应用、launcher与Agent payload提交边界支持回滚；Windows中文路径、PowerShell 3哈希和批处理错误码修复。
- 发布矩阵新增Intel macOS原生Codex smoke；同源安装包增加成员/大小检查，离线构建只复制显式文件清单。

## v1.0.0 (2026-08-29)

首发版本。

- 内置最小 Agent（ab）：单文件、零第三方依赖、流式输出，默认 Agnes 免费模型，
  支持自定义 OpenAI 兼容接口与本地模型（Ollama / LM Studio）。
- 内置离线 Linux 知识库：可查阅用法、操作系统、修复常见问题。
- 中文控制台菜单（agentboot）：环境体检 / 在线安装 Agent / 离线安装 / 模型配置 / 镜像代理。
- Agent 目录：Claude Code、Codex、Qwen Code、OpenCode、CodeBuddy、MiMo Code、Cline、
  Gemini CLI、iFlow CLI、Aider。
- 中国网络自适应：自动探测并切换 npmmirror、Node 运行时镜像、pip 清华源、代理支持。
- 一键在线安装（Linux/macOS/Windows）与一键离线安装（含自解压包）。
- Cloudflare Worker 分发：`curl -fsSL https://boot.ide.pub/install.sh | sh`。
- GitHub Pages 分发入口：`curl -fsSL https://bit-cook.github.io/AgentBoot/install.sh | sh`。
- 新增 Agent：Hermes Agent（自我进化智能体，需 Git）、OpenClaw（多渠道个人 AI 网关）、Pi Coding Agent（pi.dev 同源 npm 包）、CoCo Agent（脚本安装，Linux/macOS）。
- 新增自定义 Agent：菜单向导或 `add-agent` 命令可添加注册表之外的任意 Agent（存于用户目录，升级不丢）。
- 注册表支持 `os` 平台限制与 `requires` 前置依赖检查；脚本类安装自动加镜像兜底。
- v1.0.0 调整：CoCo Agent 置顶（vendor 更名 BitCook）；除 Aider（pip 生态）外全部 Agent 支持离线安装，离线载荷补齐 Hermes（含完整 Python 运行时）/ OpenClaw / Pi / Gemini CLI / iFlow CLI。
- 新增自定义离线包构建：菜单 [7] 向导或 `build-offline` 命令，自选平台与 Agent 生成瘦身离线包（如 win-x64 仅 Pi ≈ 89MB）。
- 模型提供商管理器：Agnes 零配置开箱即用；自定义提供商命名管理（增删切换）、本地模型预设、故障切换顺序；ab 与菜单共用。
- 文档与站点升级：产品级主页（特性卡片 / Agent 全表 / 复制按钮 / 深色模式）、README 重构、安装指南目录与 FAQ。
- 内置 Agent 深度优化：TLS 连接复用（每轮对话实测省约 440ms 首字延迟）、知识库预建索引（热查询亚毫秒）、上下文预算自动瘦身、会话持久化（`ab -c` / `/继续`）、新增跨平台 `search_files` 工具、模型源故障自动切换（`fallback`）、`/bench` 性能基准。
