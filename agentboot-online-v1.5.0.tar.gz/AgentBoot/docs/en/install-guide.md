# AgentBoot Installation Guide

> **v1.5.0** · Linux / macOS / Windows · CLI UI in Chinese by default (switchable to English: `agentboot lang en`)
> AgentBoot is a minimal, fast, ready-to-run AI Agent launcher: it ships a built-in fallback agent while Cursor, OpenCode, Claude Code, Codex, FreeBuff and the other agents are installed from a menu of your choice. Cursor, Aider, and FreeBuff are online-only; OpenCode uses pinned official native binaries in verified offline packs.

**目录 / Table of contents**: [One-command online install](#one-command-online-install) · [One-command offline install](#one-command-offline-install) · [Custom agents](#custom-agents-beyond-the-registry) · [Custom offline packages](#custom-offline-packages-slim) · [China network](#china-network-adaptive) · [Model providers](#model-providers) · [Built-in agent](#built-in-agent-ab) · [Upgrade & uninstall](#upgrade--uninstall) · [Troubleshooting](#online-install-troubleshooting) · [FAQ](#faq)

---

## ⚡ One-command online install (recommended)

**Linux / macOS**

```bash
curl -fsSL https://boot.ide.pub/install.sh | sh
```

**Windows (PowerShell / CMD)**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((New-Object Net.WebClient).DownloadString('https://boot.ide.pub/install.ps1'))"
```

**Fallback entry (GitHub Pages)** — when `ide.pub` is unavailable or its domain expires; both `/AgentBoot/` and `/agentboot/` spellings work (case-insensitive alias):

```bash
# Linux / macOS (both /AgentBoot/ and /agentboot/ spellings work)
curl -fsSL https://bit-cook.github.io/AgentBoot/install.sh | sh
```

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((New-Object Net.WebClient).DownloadString('https://bit-cook.github.io/AgentBoot/install.ps1'))"
```

**Final fallback (GitHub Releases, no custom domains required)** — works even if `ide.pub`, `osome.work`, and every other custom domain has expired:

```bash
curl -fsSL https://github.com/bit-cook/AgentBoot/releases/latest/download/install.sh | sh
```

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((New-Object Net.WebClient).DownloadString('https://github.com/bit-cook/AgentBoot/releases/latest/download/install.ps1'))"
```

> Maintainer note: `bit-cook.github.io` currently 301-redirects to the custom domain `osome.work`; if that domain ever expires, remove the custom domain under Settings → Pages of the `bit-cook.github.io` repo and `bit-cook.github.io` serves directly again. The jsDelivr mirror (`cdn.jsdelivr.net/gh/bit-cook/AgentBoot@main/install.sh`) depends on no GitHub Pages configuration at all.

The installer itself uses project-controlled origins only: `boot.ide.pub` → GitHub Pages → jsDelivr mirror → GitHub Releases, with same-origin SHA-256 enforcement.

**After install**

| Command | Purpose |
|---|---|
| `agentboot` | Chinese console menu: install agents / models / mirrors / custom offline builds |
| `ab` | Built-in fallback agent — **free Agnes model, works immediately** |

> On Windows, newly installed commands need a **new terminal window** to appear in PATH.
>
> The online installer fetches and enforces a same-origin `.sha256` sidecar, then atomically switches the complete app directory. A corrupt download or failed upgrade does not overwrite the current version.

---

## 📦 One-command offline install (no internet needed)

Three steps: **① get an offline package → ② copy & extract → ③ run the offline installer**. No internet and no unzip software required on the target machine.

### Step 1 — Get an offline package

- **Option A**: download from [Releases](https://github.com/bit-cook/AgentBoot/releases)
  - `AgentBoot-offline-v1.5.0-win-x64-codex.zip` (Windows x64)
  - `AgentBoot-offline-v1.5.0-linux-x64-codex.tar.gz` (Linux x64)
  - `AgentBoot-offline-v1.5.0-linux-x64-codex-sfx.sh` (Linux x64 self-extracting file)
- **Option B — build your own slim package** (recommended; see [Custom offline packages](#custom-offline-packages-slim)):
  pick platforms and agents, output goes to `dist/`.

### Step 2 — Extract (no unzip software needed)

| Target machine | How |
|---|---|
| Windows (any) | Right-click the ZIP → Extract All (built into Explorer) |
| Windows 10/11 (CLI) | `tar -xf AgentBoot-offline-v1.5.0-win-x64-codex.zip` |
| Linux x64 | `tar -xzf AgentBoot-offline-v1.5.0-linux-x64-codex.tar.gz -C ~` |
| Minimal Linux x64 | `sh AgentBoot-offline-v1.5.0-linux-x64-codex-sfx.sh` |

### Step 3 — Run the offline installer

**Linux / macOS**

```bash
cd ~/AgentBoot
sh install-offline.sh                     # install + open console menu
sh install-offline.sh --all               # install every offline-capable agent
sh install-offline.sh claude-code qwen-code   # specific agents only
```

**Windows**

```powershell
cd AgentBoot
powershell -NoProfile -ExecutionPolicy Bypass -File install-offline.ps1          # install + menu
powershell -NoProfile -ExecutionPolicy Bypass -File install-offline.ps1 -All     # all agents
powershell -NoProfile -ExecutionPolicy Bypass -File install-offline.ps1 -Agents claude-code,qwen-code
```

### What the offline installer does

The target verifies every payload file against the bundled `PAYLOAD_SHA256SUMS.txt`; missing or mismatched bytes stop installation. `--all` installs only the Agents listed by that pack's `MANIFEST.txt`.

1. Verifies the `payloads/` bundle integrity;
2. Installs the AgentBoot app itself;
3. Python: system python3 on Linux/macOS; on Windows deploys a **portable Python** from the package (no admin);
4. Node: deploys the bundled Node 22 runtime when the system has none;
5. Copies the selected agents' payloads directly (no npm), generates command shims;
6. Registers `~/.local/bin` (Windows: `%LOCALAPPDATA%\AgentBoot\bin`) into the user PATH (idempotent);
7. `ab` works immediately: Agnes free model online; local models (Ollama / LM Studio) for fully-offline machines.

### Offline package layout

```
AgentBoot/
├── install-offline.sh / .ps1
├── MANIFEST.txt
├── core/ agents/ tools/ scripts/ ...
└── payloads/
    ├── python/win-embed.zip
    ├── node/<linux-x64|win-x64|darwin-arm64>/
    └── agents/<agent-id>/<platform>/node_modules/
```

### Offline troubleshooting

| Symptom | Fix |
|---|---|
| "payloads/ not found" | Run from the extracted package root, or pass `--payload <path>` |
| No python3 on Linux | `apt install python3` / `dnf install python3` / `apk add python3`, then re-run |
| Command not found after install | Reopen the terminal; or `export PATH="$HOME/.local/bin:$PATH"` |
| Missing payload for an agent | The selected pack does not contain it — rebuild on the target platform with menu [7] |
| `ab` can't reach the model | Expected fully offline — configure a local model in menu [4] |

---

## 🧩 Custom agents (beyond the registry)

**Menu wizard**: `agentboot` → `[2]` → `+` → pick method (npm / pip / install-script URL), name and command → save & optionally install. Appears in the list with a ★.

**Command line**

```bash
python core/menu.py add-agent myagent npm @scope/some-agent some-cmd
python core/menu.py add-agent myagent pip some-agent-pkg some-cmd
python core/menu.py add-agent myagent script "https://example.com/install.sh" some-cmd
python core/menu.py add-agent --list
python core/menu.py add-agent --del myagent
```

Stored in `~/.agentboot/custom-agents.json` — survives upgrades. Same install pipeline as built-ins (mirrors included).

> Hermes' offline payload contains a platform-specific Python venv and must be built on its target platform (for example, Windows on Windows and darwin-arm64 on Apple Silicon). The builder explicitly drops cross-target Hermes partial payloads instead of shipping a package that cannot run. Other npm Agents still support cross-target `--os/--cpu` packaging.

## 📦 Custom offline packages (slim)

The v1.3 Release provides verified Codex and OpenCode slim packs. Build a target-platform pack with only what you need:

**Menu**: `agentboot` → `[7] Build custom offline package` → pick platforms → pick agents → build.

**CLI**

```bash
python core/menu.py build-offline win-x64 claude-code,pi
python core/menu.py build-offline linux-x64,darwin-arm64 coco,pi,hermes
```

Custom packs use the same structure and install flow as Release packs. Size depends on the selected Agents and runtimes. The build machine needs internet; Hermes also requires Git and must be built natively on the target platform.

## 🌏 China network adaptive

- Auto-detects `registry.npmjs.org` reachability and enables mirror mode;
- npm registries (switchable): npmmirror / Tencent Cloud / Huawei Cloud / official, applied to npm-based agent installs automatically;
- Node runtimes: npmmirror → Huawei Cloud → Tencent Cloud binary mirrors in order (nodejs.org as final fallback);
- GitHub acceleration (switchable): gh-proxy.com / ghfast.top / ghproxy.net, probe-ordered, can be pinned or disabled (direct);
- pip → Tsinghua mirror;
- Multi-source downloads: project-controlled `boot.ide.pub` → GitHub Pages → jsDelivr → GitHub Releases, each with same-origin SHA-256;
- Proxy: menu `[5]`, stored for npm and AgentBoot downloads;
- Switch in menu `[5]`, or via CLI: `agentboot mirror npm [registry-url]`, `agentboot mirror gh [auto|off|prefix-url]`; force mirror mode with `AGENTBOOT_MIRROR=cn|off`.

## 🧠 Model providers

`ab` → `/model`, or menu `[4]` — both open the **model provider manager**:

```
---- Model Providers ----
  [1] agnes     agnes-2.5-flash  (https://apihub.agnes-ai.com/v1) ← current
  [s] Switch   [a] Add provider   [d] Remove provider
  [f] Failover order   [t] Test current   [0] Done
```

- **Agnes free model** (built-in preset): zero config, first run works;
- **Custom providers**: any OpenAI-compatible endpoint, named, switchable, removable;
- **Local models (fully offline)**: built-in Ollama (11434) and LM Studio (1234) presets; add vLLM as a custom OpenAI-compatible provider;
- **Failover order**: primary failure switches automatically (e.g. `agnes → ollama`);
- Config file: `~/.agentboot/config.json`.

**Which agents talk to Agnes out of the box?** Codex and Qwen Code are auto-wired (config.toml / OPENAI_* env) after install; OpenCode gets an `opencode.json`; Claude Code (Anthropic protocol) and Gemini CLI (Google protocol) need their own accounts.

## 🧰 Built-in agent (ab)

Single file, zero third-party dependencies (Python stdlib only), sub-second startup:

- Tools: run commands (dangerous ones blocked/confirmed), read/write/edit files, list dirs, `search_files`, fetch web pages;
- Offline Linux knowledge base (9 topics, 60+ sections) — usage lookups, operations, fixing common problems;
- Streaming output, session persistence (`ab -c`, `/继续`), context auto-trimming, `/bench` benchmark;

```bash
ab                                  # interactive
ab run "check disk usage"           # one-shot task
ab linux 查看端口占用                # query the knowledge base
ab doctor                           # environment check
ab bench                            # performance benchmark
```

## 🔧 Upgrade & uninstall

```bash
# upgrade: re-run the online one-liner (config preserved)
curl -fsSL https://boot.ide.pub/install.sh | sh

# uninstall one or more Agents (keeps config, credentials, and sessions)
agentboot uninstall codex
agentboot uninstall codex,qwen-code

# remove CoCo and its user data (irreversible)
agentboot uninstall coco --purge

# uninstall AgentBoot itself (also removes AgentBoot config)
rm -rf ~/.agentboot ~/.local/bin/agentboot ~/.local/bin/ab        # Linux/macOS
rmdir /s /q "%USERPROFILE%\.agentboot" & rmdir /s /q "%LOCALAPPDATA%\AgentBoot"   # Windows
```

For a complete POSIX uninstall, also remove the block from `# >>> agentboot >>>` through `# <<< agentboot <<<` in `.bashrc`, `.profile`, and `.zshrc`. On Windows, remove the two AgentBoot bin entries from the user `Path`.

Before extraction, download the Release's `SHA256SUMS.txt` and run `sha256sum -c SHA256SUMS.txt --ignore-missing`. The bundled `PAYLOAD_SHA256SUMS.txt` performs a second, per-file check after extraction.

You can also choose menu `[9] Uninstall Agents`. AgentBoot records ownership in `~/.agentboot/installed-agents.json`, so an unrelated command with the same name is never removed. Normal uninstall preserves every Agent's config and sessions; `--purge` currently has a defined data-removal boundary for CoCo only. Legacy installs are cleaned automatically only when ownership can be proven from an AgentBoot payload directory or marked shim; otherwise the command stops with manual removal guidance.

## ❓ Online install troubleshooting

| Symptom | Fix |
|---|---|
| `curl` missing | `wget -qO- https://boot.ide.pub/install.sh \| sh`, or install curl |
| All sources fail | Use the offline package, or set a proxy first |
| Windows "scripts disabled" | Use the `-ExecutionPolicy Bypass` command from the docs |
| python3 auto-install failed | Install Python manually, then re-run |
| `agentboot` not found | Reopen terminal / `source ~/.bashrc`; on Windows open a new terminal |

## ❓ FAQ

**Which agents work with the free Agnes model right after install?**
Codex and Qwen Code are auto-wired; OpenCode gets an `opencode.json`; the built-in `ab` always defaults to Agnes. Claude Code (Anthropic protocol) and Gemini CLI (Google protocol) need their own accounts.

**Why is codex pinned to 0.90.0?**
0.100+ removed the chat wire protocol and 0.15x sends private tool types that OpenAI-compatible gateways reject. The pin keeps Agnes working out of the box; upgrade and use official login if you prefer.

**Release pack or custom pack?**
Slim when the target machine needs 1–2 agents (e.g. 89MB win-x64 + Pi); full when unsure. Missing agents in a slim package are reported clearly during install.

**How do I verify performance?**
`ab bench` — KB query latency (cold/warm), model first-token latency with and without TLS handshake.
