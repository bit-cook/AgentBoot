#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AgentBoot 控制台菜单（命令 agentboot）
================================
中文交互菜单：
  * 环境体检
  * 在线安装 Agent（菜单多选：Claude Code / Codex / Qwen Code / OpenCode / CodeBuddy / MiMo / Cline / Gemini CLI / iFlow / FreeBuff ...）
  * 离线安装 Agent（从离线包 payloads/ 直接落盘，无需 npm）
  * 模型配置（Agnes 免费预设 / 自定义 OpenAI 兼容 / 本地 Ollama、LM Studio）
  * 镜像与代理设置（中国网络环境自适应：npmmirror 等）
也提供非交互子命令供脚本调用：
  python menu.py doctor
  python menu.py install claude-code,qwen-code
  python menu.py uninstall claude-code,qwen-code [--purge]
  python menu.py offline claude-code --payload /path/payloads
  python menu.py mirror auto|off|cn|proxy http://127.0.0.1:7890
"""
import json
from contextlib import contextmanager

import os
import re
import sys
import threading
import time

# 启动性能（v1.7.0 极限优化）：subprocess/shutil/platform 只在安装、卸载、
# 构建、下载等路径才需要，菜单渲染与版本查询用不到。顶层导入它们让每次
# `agentboot` 启动多付约 15ms（实测 import menu ≈ 67ms vs import agent
# ≈ 50ms，基线 46ms）。用惰性代理：内部裸名引用与外部 patch
# （mock.patch.object(menu, "subprocess")）都正常工作，首次真正调用时才
# 导入真模块（PEP 562 的模块 __getattr__ 管不了模块内部的裸名，故用代理）。
class _LazyModule:
    """按需加载的模块代理：属性访问触发真导入，之后缓存。"""

    __slots__ = ("_ab_name", "_ab_mod")

    def __init__(self, name):
        object.__setattr__(self, "_ab_name", name)
        object.__setattr__(self, "_ab_mod", None)

    def _ab_load(self):
        mod = object.__getattribute__(self, "_ab_mod")
        if mod is None:
            import importlib
            mod = importlib.import_module(object.__getattribute__(self, "_ab_name"))
            object.__setattr__(self, "_ab_mod", mod)
        return mod

    def __getattr__(self, attr):
        if attr.startswith("_ab_"):
            raise AttributeError(attr)
        return getattr(self._ab_load(), attr)

    def __setattr__(self, attr, value):
        # 转发设置到真模块：mock.patch.object(menu.subprocess, "Popen")
        # 这类测试补丁才能工作（与惰性化之前直接 patch 真模块语义一致）。
        if attr.startswith("_ab_"):
            object.__setattr__(self, attr, value)
            return
        setattr(self._ab_load(), attr, value)

    def __delattr__(self, attr):
        if attr.startswith("_ab_"):
            object.__delattr__(self, attr)
            return
        delattr(self._ab_load(), attr)


subprocess = _LazyModule("subprocess")
shutil = _LazyModule("shutil")
platform = _LazyModule("platform")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import agent  # noqa: E402  复用配置与模型能力
import i18n  # noqa: E402  双语支持

t = i18n.t

APP_DIR = agent.APP_DIR
VERSION = agent.VERSION
AB_HOME = agent.AB_HOME
RUNTIME_DIR = os.path.join(AB_HOME, "runtime")
AGENTS_DIR = os.path.join(AB_HOME, "agents")
NPM_PREFIX = os.path.join(AB_HOME, "npm-prefix")
APPS_DIR = os.path.join(AB_HOME, "apps")

NODE_VERSION = "v22.23.2"
NPM_OFFICIAL = "https://registry.npmjs.org"
# 国内 npm registry 镜像（镜像菜单可切换；默认首选 npmmirror，其余自动兜底）
NPM_MIRRORS = (
    ("npmmirror（阿里）", "https://registry.npmmirror.com"),
    ("腾讯云", "https://mirrors.cloud.tencent.com/npm/"),
    ("华为云", "https://mirrors.huaweicloud.com/repository/npm/"),
)
NPM_MIRROR = NPM_MIRRORS[0][1]           # 兼容旧引用：默认国内镜像
NODE_MIRRORS = (                          # Node 二进制分发镜像（含 SHASUMS256.txt）
    ("npmmirror（阿里）", "https://registry.npmmirror.com/-/binary/node"),
    ("华为云", "https://mirrors.huaweicloud.com/nodejs"),
    ("腾讯云", "https://mirrors.cloud.tencent.com/nodejs-release"),
)
NODE_MIRROR_CN = NODE_MIRRORS[0][1]      # 兼容旧引用
NODE_MIRROR_GLOBAL = "https://nodejs.org/dist"
PIP_MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"
# GitHub 加速前缀（拼接在 https://github.com/... 原地址之前；镜像菜单可切换/关闭）
GH_PROXIES = (
    ("gh-proxy.com", "https://gh-proxy.com/"),
    ("ghfast.top", "https://ghfast.top/"),
    ("ghproxy.net", "https://ghproxy.net/"),
)

CUSTOM_AGENTS = os.path.join(AB_HOME, "custom-agents.json")
INSTALL_STATE = os.path.join(AB_HOME, "installed-agents.json")

POSIX = os.name != "nt"

CURSOR_VERSION = "3.18"
CURSOR_DOWNLOADS = {
    "linux-x64": "https://api2.cursor.sh/updates/download/golden/linux-x64/cursor/3.18",
    "linux-arm64": "https://api2.cursor.sh/updates/download/golden/linux-arm64/cursor/3.18",
    "darwin-x64": "https://api2.cursor.sh/updates/download/golden/darwin-x64/cursor/3.18",
    "darwin-arm64": "https://api2.cursor.sh/updates/download/golden/darwin-arm64/cursor/3.18",
    "win-x64": "https://api2.cursor.sh/updates/download/golden/win32-x64-user/cursor/3.18",
    "win-arm64": "https://api2.cursor.sh/updates/download/golden/win32-arm64-user/cursor/3.18",
}
CURSOR_MAX_BYTES = 600 * 1024 * 1024
# 注意：api2.cursor.sh 的 golden 渠道会重 build 同一版本号（哈希随之变化），
# 因此这里的钉值需要随上游重建而刷新；校验失败时的提示已说明这一点。
# 仅 Linux 分支使用 SHA-256 钉值；Windows/macOS 走签名验证（Authenticode/codesign/spctl）。
CURSOR_SHA256 = {
    "linux-x64": "874d17528bbe288bfcb5c8f2dc26c3f1ca61b49862d3590afcef4a9c68efef7d",
    "linux-arm64": "ec03879fca957065623d2274b39cd814d3209692cb4864f25859284cfb1302ec",
}


# ---------------------------------------------------------------- 基础工具

def log_ok(msg):  print("✓ %s" % msg)
def log_err(msg): print("✗ %s" % msg)
def log_info(msg): print("· %s" % msg)


def plat_id():
    s = platform.system().lower()
    if s == "windows":
        s = "win"
    m = platform.machine().lower()
    if m in ("amd64", "x86_64"):
        arch = "x64"
    elif m in ("arm64", "aarch64"):
        arch = "arm64"
    else:
        raise RuntimeError("不支持的 CPU 架构：%s" % m)
    if s not in ("linux", "darwin", "win"):
        raise RuntimeError("不支持的操作系统：%s" % s)
    return "%s-%s" % (s, arch)


def can_tcp(host, port=443, timeout=2.0):
    import socket
    try:
        socket.create_connection((host, port), timeout=timeout).close()
        return True
    except Exception:
        return False


def python_ok(path):
    """验证 python 可真实执行（排除 Windows 商店的 python 存根）。"""
    if not path:
        return False
    try:
        r = subprocess.run([path, "-c", "print(1)"], capture_output=True, timeout=20)
        return r.returncode == 0
    except Exception:
        return False


def find_python():
    for cand in (shutil.which("python3"), shutil.which("python"), shutil.which("py")):
        if python_ok(cand):
            return cand
    return None


_ENV_JSON_CACHE = {"path": None, "data": None, "mtime": None}


def env_json_path():
    """env.json 的当前位置：跟随 AB_HOME（含测试里的临时目录），不能冻结成常量。

    v1.5.2 之前这里是一个模块导入时算死的常量，测试 mock AB_HOME 后读写
    仍落在真实用户目录（曾把测试代理配置写进真实 env.json）。"""
    return os.path.join(AB_HOME, "env.json")


def load_env_json():
    """读取 env.json（按 path+mtime 缓存；cn_mode 等高频调用不再反复读盘）。返回浅拷贝。"""
    path = env_json_path()
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        mtime = None
    cached = _ENV_JSON_CACHE["data"]
    if (cached is None or _ENV_JSON_CACHE["path"] != path
            or _ENV_JSON_CACHE["mtime"] != mtime):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            cached = data if isinstance(data, dict) else {}
        except Exception:
            cached = {}
        _ENV_JSON_CACHE["data"] = cached
        _ENV_JSON_CACHE["path"] = path
        _ENV_JSON_CACHE["mtime"] = mtime
    data = dict(cached)
    proxy = data.get("proxy")
    if proxy:
        os.environ["HTTP_PROXY"] = proxy
        os.environ["HTTPS_PROXY"] = proxy
    return data


def save_env_json(data):
    path = env_json_path()
    agent._atomic_private_json(path, data)
    _ENV_JSON_CACHE["data"] = dict(data)
    _ENV_JSON_CACHE["path"] = path
    try:
        _ENV_JSON_CACHE["mtime"] = os.path.getmtime(path)
    except OSError:
        _ENV_JSON_CACHE["mtime"] = None


def _mirror_mode_pref():
    """镜像模式偏好：环境变量 > env.json 持久化选择 > 空（自动探测）。"""
    forced = os.environ.get("AGENTBOOT_MIRROR", "").strip().lower()
    if forced:
        return forced
    return (load_env_json().get("mirror_mode") or "").strip().lower()


def set_mirror_mode(mode):
    """持久化镜像模式（auto/cn/off），并同步当前进程环境。"""
    mode = (mode or "auto").strip().lower()
    if mode in ("cn", "on", "1", "true"):
        mode = "cn"
    elif mode in ("off", "global", "0", "false"):
        mode = "off"
    elif mode in ("auto", ""):
        mode = "auto"
    else:
        log_err("镜像模式必须是 auto / cn / off")
        return
    data = load_env_json()
    if mode == "auto":
        data.pop("mirror_mode", None)
    else:
        data["mirror_mode"] = mode
    # npm 源跟随模式：cn 固定国内镜像，off/auto 恢复自动选路——
    # 否则 off 后状态栏显示「国际网络」而 npm 仍固定 npmmirror，自相矛盾
    if mode == "cn":
        data["npm_registry"] = NPM_MIRROR
    else:
        data.pop("npm_registry", None)
    save_env_json(data)
    os.environ.pop("AGENTBOOT_MIRROR", None)
    if npm_cmd():
        set_npm_registry(npm_registry(False if mode == "off" else None))
    if mode == "cn":
        log_ok("镜像模式已固定为中国网络（npm 用 %s，GitHub 加速启用）" % NPM_MIRROR)
    elif mode == "off":
        log_ok("镜像模式已固定为全球直连（npm 源恢复官方）")
    else:
        log_ok("镜像模式已恢复自动探测")


def cn_mode():
    """中国网络环境判定：环境变量/env.json 持久化优先，其次探测 npm 官方源连通性。"""
    forced = _mirror_mode_pref()
    if forced in ("cn", "on", "1", "true"):
        return True
    if forced in ("off", "global", "0", "false"):
        return False
    return not can_tcp("registry.npmjs.org", 443, 1.5)


# ---------------------------------------------------------------- 模型预置开关

def preset_model_enabled():
    """安装第三方 Agent 时是否预置 Agnes 模型 provider。

    默认关（原版安装）：Agent 装好后保持厂商默认状态，首次运行时由用户
    自己登录/配置模型。开启后安装即写入 Agnes 免费模型配置。
    优先级：环境变量 AGENTBOOT_PRESET_MODEL > env.json 持久化 > 默认关。
    """
    env = os.environ.get("AGENTBOOT_PRESET_MODEL")
    if env is not None and env.strip():
        return env.strip().lower() in ("1", "true", "yes", "on")
    return bool(load_env_json().get("preset_agent_model"))


def set_preset_model(on):
    """持久化「安装时预置模型」开关。"""
    data = load_env_json()
    if on:
        data["preset_agent_model"] = True
    else:
        data.pop("preset_agent_model", None)
    save_env_json(data)
    if on:
        log_ok("已开启：安装 Agent 时预置 Agnes 免费模型")
    else:
        log_ok("已关闭：安装 Agent 保持原版（默认，首次运行时自选模型）")


def _resolve_preset(preset):
    """install/offline 的 --preset / --no-preset 一次性覆盖；None 用持久化设置。"""
    if preset is None:
        return preset_model_enabled()
    return bool(preset)


def _preset_flag(args):
    """解析 --preset / --no-preset；未出现返回 None（用持久化设置）。"""
    if "--preset" in args and "--no-preset" in args:
        log_err("--preset 与 --no-preset 不能同时使用")
        raise SystemExit(2)
    if "--no-preset" in args:
        return False
    if "--preset" in args:
        return True
    return None


def preset_status_line():
    """安装前的一句话透明度提示：本次会不会预置模型。"""
    if preset_model_enabled():
        log_info("本次安装将预置 Agnes 免费模型（--no-preset 可改为原版安装）")
    else:
        log_info("原版安装：不预置模型，首次运行时自选（--preset 可改为预置 Agnes）")


# ---------------------------------------------------------------- 安装版本选择

def _version_sort_key(v):
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def agent_npm_versions(a, count=12):
    """拉取该 Agent 的可用稳定版本（最新在前）。

    数据源：npm registry 的 packument（国内走 npmmirror，海外走 npmjs），
    过滤掉预发布/Dev 构建与平台分包（如 0.166.0-linux-x64）。网络失败
    返回 []——调用方按「用默认（最新）」处理。
    """
    spec = a.get("npm") or ""
    pkg = _npm_package_name_from_spec(spec)
    if not pkg:
        return []
    from urllib.request import Request, urlopen
    from urllib.parse import quote
    hosts = (["https://registry.npmmirror.com"] if cn_mode()
             else ["https://registry.npmjs.org"])
    hosts.append("https://registry.npmmirror.com" if "npmjs.org" in hosts[0]
                 else "https://registry.npmjs.org")
    for host in hosts:
        try:
            req = Request("%s/%s" % (host, quote(pkg, safe="")),
                          headers={"Accept": "application/vnd.npm.install-v1+json",
                                   "User-Agent": "AgentBoot"})
            with urlopen(req, timeout=15) as resp:
                data = json.load(resp)
            stable = [v for v in (data.get("versions") or {})
                      if re.fullmatch(r"\d+\.\d+\.\d+", v)]
            stable.sort(key=_version_sort_key, reverse=True)
            latest = (data.get("dist-tags") or {}).get("latest")
            if latest and latest not in stable:
                stable.insert(0, latest)
            return stable[:count]
        except Exception:
            continue
    return []


def resolve_npm_spec(a, version=None):
    """按用户选择生成 npm 安装 spec。

    version=None → 用 registry 默认（现在一律不带版本号=最新）；
    指定了版本 → 替换默认 spec 里的版本（或追加）。
    """
    spec = (a.get("npm") or "").strip()
    if not version:
        return spec
    version = str(version).strip().lstrip("v=@")
    pkg = _npm_package_name_from_spec(spec)
    if not pkg:
        return spec
    return "%s@%s" % (pkg, version)


def parse_agent_version_tokens(tokens):
    """解析 CLI 里的 <id>@<version> 记号，返回 {agent_id: version}。"""
    versions = {}
    for tok in tokens:
        if "@" in tok and not tok.startswith("@"):
            aid, _, version = tok.partition("@")
            if aid and version:
                versions[aid] = version
    return versions


def preset_version_warning(aid, version):
    """Agnes 预设 + codex 新版的兼容性提醒（0.100+ 移除 chat 协议）。"""
    if aid != "codex" or not version:
        return
    try:
        if _version_sort_key(version.lstrip("v")) > (0, 90, 0):
            log_err("注意：codex %s 已移除 chat 协议，与 Agnes 预设不兼容；" % version)
            log_err("      如使用 Agnes 预设请改装 codex@0.90.0；官方登录不受影响。")
    except ValueError:
        pass


def npm_registry(cn=None):
    """安装使用的 npm 源：用户固定选择（env.json）优先，其次按网络自动选路。"""
    chosen = (load_env_json().get("npm_registry") or "").strip()
    if chosen:
        return chosen
    if cn is None:
        cn = cn_mode()
    return NPM_MIRROR if cn else NPM_OFFICIAL


def set_npm_mirror(url=None):
    """固定/恢复 npm 源选择，并同步 npm config。None=恢复自动选路。"""
    data = load_env_json()
    if not url or url.rstrip("/") == NPM_OFFICIAL.rstrip("/"):
        data.pop("npm_registry", None)
        save_env_json(data)
        log_ok("npm 源已恢复自动选路（国内 %s · 全球 %s）" % (NPM_MIRROR, NPM_OFFICIAL))
        if npm_cmd():
            set_npm_registry(NPM_OFFICIAL)
        return
    data["npm_registry"] = url
    save_env_json(data)
    log_ok("npm 源已固定为 %s" % url)
    if npm_cmd():
        set_npm_registry(url)


def gh_mirrors():
    """GitHub 加速前缀列表：用户固定选择优先；auto 时（国内）探测排序；off/全球直连返回 []。"""
    from urllib.parse import urlsplit
    chosen = (os.environ.get("AGENTBOOT_GH_PROXY", "").strip()
              or (load_env_json().get("gh_proxy") or "").strip())
    prefixes = [p for _, p in GH_PROXIES]
    if chosen.lower() in ("off", "direct", "none", "0"):
        return []
    if chosen:
        first = chosen if chosen.endswith("/") else chosen + "/"
        return [first] + [p for p in prefixes if p != first]
    if not cn_mode():
        return []
    probes = agent.probe_hosts(tuple(urlsplit(p).hostname for p in prefixes), timeout=1.5)
    alive = [p for p in prefixes if probes.get(urlsplit(p).hostname)]
    dead = [p for p in prefixes if not probes.get(urlsplit(p).hostname)]
    return alive + dead   # 探测全部失败时仍按原序尝试，避免误杀可用源


def set_gh_proxy(value="auto"):
    """固定 GitHub 加速选择：auto（恢复自动）/ off（直连）/ 具体加速前缀 URL。"""
    data = load_env_json()
    v = (value or "auto").strip()
    if v.lower() in ("auto", ""):
        data.pop("gh_proxy", None)
        log_ok("GitHub 加速已恢复自动选路（国内探测 %d 个加速源，全球直连）" % len(GH_PROXIES))
    elif v.lower() in ("off", "direct", "none"):
        data["gh_proxy"] = "off"
        log_ok("GitHub 加速已关闭（始终直连）")
    elif v.startswith("http://") or v.startswith("https://"):
        if not v.endswith("/"):
            v += "/"
        data["gh_proxy"] = v
        log_ok("GitHub 加速已固定为 %s（其余加速源自动兜底）" % v)
    else:
        log_err("加速源必须是 http(s) 前缀 URL，或 auto / off")
        return
    save_env_json(data)
    os.environ.pop("AGENTBOOT_GH_PROXY", None)


def load_registry():
    """内置注册表 + 用户自定义（custom-agents.json），同名 id 以先出现的内置为准。"""
    path = os.path.join(APP_DIR, "agents", "registry.json")
    with open(path, "r", encoding="utf-8") as f:
        agents = json.load(f)["agents"]
    builtin_ids = {a["id"] for a in agents}
    for c in load_custom_agents():
        if c.get("id") in builtin_ids:
            continue
        c["custom"] = True
        agents.append(c)
    return agents


def load_custom_agents():
    try:
        with open(CUSTOM_AGENTS, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_custom_agents(items):
    agent._atomic_private_json(CUSTOM_AGENTS, items)


def load_install_state():
    """读取 AgentBoot 安装归属清单；损坏文件按空清单处理。"""
    try:
        with open(INSTALL_STATE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("agents"), dict):
            return data
    except (OSError, ValueError, TypeError):
        pass
    return {"version": 1, "agents": {}}


def save_install_state(data):
    """同目录临时文件 + os.replace，避免中断时写坏安装清单。"""
    os.makedirs(AB_HOME, exist_ok=True)
    tmp = INSTALL_STATE + ".%s.tmp" % os.getpid()
    try:
        with open(tmp, "w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, INSTALL_STATE)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


@contextmanager
def _install_state_lock():
    os.makedirs(AB_HOME, mode=0o700, exist_ok=True)
    lock_path = INSTALL_STATE + ".lock"
    with open(lock_path, "a+b") as lock:
        if os.path.getsize(lock_path) == 0:
            lock.write(b"\0")
            lock.flush()
        lock.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            lock.seek(0)
            if os.name == "nt":
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def record_install(a, source, executable=None, install_prefix=None):
    """记录由 AgentBoot 完成的安装，作为安全卸载的归属依据。"""
    with _install_state_lock():
        state = load_install_state()
        state["version"] = 1
        state["agents"][a["id"]] = {
            "name": a.get("name") or a["id"], "bin": a.get("bin"), "source": source,
            "method": a.get("method", "npm"),
            "package": a.get("npm") or a.get("pip") or a.get("script"),
            "executable": executable, "prefix": install_prefix,
            "custom": bool(a.get("custom")), "installed_at": int(time.time()),
        }
        save_install_state(state)


def forget_install(aid):
    with _install_state_lock():
        state = load_install_state()
        if state["agents"].pop(aid, None) is not None:
            save_install_state(state)


def custom_add_entry(entry):
    """添加一条自定义 Agent（id 重复时拒绝）。返回是否成功。"""
    if not _valid_agent_id(entry.get("id")) or not _valid_bin_name(entry.get("bin")):
        raise ValueError("Agent id/命令名只能包含字母、数字、点、下划线与连字符")
    items = load_custom_agents()
    registry_path = os.path.join(APP_DIR, "agents", "registry.json")
    try:
        with open(registry_path, "r", encoding="utf-8") as source:
            builtins = {item.get("id") for item in json.load(source).get("agents", [])}
    except Exception:
        builtins = set()
    if entry["id"] in builtins or any(item.get("id") == entry["id"] for item in items):
        raise ValueError("Agent id 已存在：%s" % entry["id"])
    entry["offline"] = False
    entry.setdefault("vendor", "自定义")
    items.append(entry)
    save_custom_agents(items)


def custom_remove_entry(aid):
    items = [a for a in load_custom_agents() if a.get("id") != aid]
    save_custom_agents(items)


def _slug(name):
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "custom"


def _valid_agent_id(value):
    return bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", str(value or "")))


def _valid_bin_name(value):
    return bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", str(value or "")))


def custom_add_wizard():
    """交互式添加自定义 Agent 向导。返回新 id 或 None。"""
    print("\n---- 添加自定义 Agent ----")
    print("安装方式：[1] npm 包  [2] pip 包  [3] 安装脚本 URL")
    m = {"1": "npm", "2": "pip", "3": "script"}.get(input("选择: ").strip())
    if not m:
        log_err("无效方式")
        return None
    if m == "npm":
        pkg = input("npm 包名（如 @scope/xxx）: ").strip()
    elif m == "pip":
        pkg = input("pip 包名: ").strip()
    else:
        pkg = input("安装脚本 URL: ").strip()
    if not pkg:
        log_err("不能为空")
        return None
    default_id = _slug(pkg.split("/")[-1])
    aid = input("id（回车=%s）: " % default_id).strip() or default_id
    name = input("显示名（回车=%s）: " % aid).strip() or aid
    default_bin = pkg.split("/")[-1].split("@")[-1] if m == "npm" else aid
    bin_ = input("安装后的命令（回车=%s）: " % default_bin).strip() or default_bin
    if not _valid_agent_id(aid) or not _valid_bin_name(bin_):
        log_err("id 与命令名只能包含字母、数字、点、下划线与连字符")
        return None
    entry = {"id": aid, "name": name, "desc": "自定义 Agent", "bin": bin_, "method": m,
             "requires": [], "notes": ["用户自定义条目"]}
    if m == "npm":
        entry["npm"] = pkg
    elif m == "pip":
        entry["pip"] = pkg
    else:
        entry["script"] = pkg
    try:
        custom_add_entry(entry)
    except ValueError as error:
        log_err(str(error))
        return None
    log_ok("已保存到 %s" % CUSTOM_AGENTS)
    return aid


def runtime_node_dir():
    return os.path.join(RUNTIME_DIR, "node-%s" % plat_id())


def node_exe():
    d = runtime_node_dir()
    return os.path.join(d, "node.exe") if not POSIX else os.path.join(d, "bin", "node")


def npm_cmd(minimum=None, version_cache=None):
    """优先系统 npm，其次运行时自带 npm。"""
    n = shutil.which("npm")
    system_node = shutil.which("node")
    if n and node_ok(system_node, minimum, version_cache):
        return n
    d = runtime_node_dir()
    cand = os.path.join(d, "npm.cmd") if not POSIX else os.path.join(d, "bin", "npm")
    return cand if os.path.exists(cand) and node_ok(node_exe(), minimum, version_cache) else None


def child_env():
    env = dict(os.environ)
    nd = runtime_node_dir()
    if os.path.isdir(nd):
        env["PATH"] = (os.path.join(nd, "") if POSIX else nd + os.sep) + os.pathsep + \
                      (os.path.join(nd, "bin") + os.pathsep if POSIX else "") + env.get("PATH", "")
    p = load_env_json().get("proxy")
    if p:
        env.setdefault("HTTP_PROXY", p)
        env.setdefault("HTTPS_PROXY", p)
    return env


# ---------------------------------------------------------------- Node 运行时

def _version_tuple(value):
    match = re.search(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", str(value or ""))
    if not match:
        return None
    return tuple(int(part or 0) for part in match.groups())


def _version_satisfies(current, requirement):
    """Evaluate the simple npm engine ranges used by AgentBoot's registry."""
    for clause in str(requirement or ">=18").split("||"):
        matched = True
        comparisons = re.findall(r"(>=|<=|>|<|=)?\s*(\d+(?:\.\d+){0,2})", clause)
        if not comparisons:
            continue
        for operator, raw in comparisons:
            target = _version_tuple(raw)
            if operator == ">=" and not current >= target: matched = False
            elif operator == ">" and not current > target: matched = False
            elif operator == "<=" and not current <= target: matched = False
            elif operator == "<" and not current < target: matched = False
            elif operator in ("", "=") and not current == target: matched = False
        if matched:
            return True
    return False


def node_ok(path=None, minimum=None, version_cache=None):
    try:
        executable = path or shutil.which("node") or node_exe()
        current = version_cache.get(executable) if version_cache is not None else None
        if current is None:
            out = subprocess.run([executable, "--version"],
                                 capture_output=True, text=True, timeout=10)
            if out.returncode != 0:
                return False
            current = _version_tuple(out.stdout.strip())
            if current and version_cache is not None:
                version_cache[executable] = current
        return bool(current and _version_satisfies(current, minimum or ">=18"))
    except Exception:
        pass
    return False


def ensure_node(minimum=None):
    """确保 Node 满足 Agent 最低版本；不足时部署便携运行时。"""
    import hashlib
    from urllib import request as urllib_request
    sysnode = shutil.which("node")
    if sysnode and node_ok(sysnode, minimum):
        return sysnode
    if os.path.exists(node_exe()) and node_ok(node_exe(), minimum):
        return node_exe()

    pid = plat_id()
    cn = cn_mode()
    if pid.startswith("win"):
        fname = "node-%s-win-x64.zip" % NODE_VERSION
        inner = "node-%s-win-x64" % NODE_VERSION
    else:
        ext = "tar.gz" if pid.startswith("darwin") else "tar.xz"
        fname = "node-%s-%s.%s" % (NODE_VERSION, pid, ext)
        inner = "node-%s-%s" % (NODE_VERSION, pid)
    # 国内走多镜像，全球走官方；官方源始终作为最终兜底
    bases = [b for _, b in NODE_MIRRORS] if cn else [NODE_MIRROR_GLOBAL]
    if NODE_MIRROR_GLOBAL not in bases:
        bases.append(NODE_MIRROR_GLOBAL)
    urls = ["/".join([b, NODE_VERSION, fname]) for b in bases]

    dest_parent = RUNTIME_DIR
    os.makedirs(dest_parent, exist_ok=True)
    archive = os.path.join(dest_parent, fname)
    sums_path = os.path.join(dest_parent, "SHASUMS256-%s.txt" % NODE_VERSION)
    ok = False
    for u in urls:
        try:
            log_info("下载 Node 运行时：%s" % u)
            req = urllib_request.Request(u, headers={"User-Agent": "AgentBoot/1.0"})
            with urllib_request.urlopen(req, timeout=60) as r, open(archive, "wb") as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
            ok = True
            break
        except Exception as e:
            log_err("下载失败(%s)：%s" % (u, e))
    if not ok:
        return None
    try:
        if not os.path.exists(sums_path):
            sums_ok = False
            for b in bases:
                sums_url = "%s/%s/SHASUMS256.txt" % (b, NODE_VERSION)
                try:
                    log_info("下载校验文件：%s" % sums_url)
                    req = urllib_request.Request(sums_url, headers={"User-Agent": "AgentBoot/1.0"})
                    with urllib_request.urlopen(req, timeout=60) as response, open(sums_path, "wb") as output:
                        shutil.copyfileobj(response, output)
                    sums_ok = True
                    break
                except Exception as e:
                    log_err("校验文件下载失败(%s)：%s" % (sums_url, e))
            if not sums_ok:
                return None
        expected = None
        with open(sums_path, "r", encoding="ascii") as sums:
            for line in sums:
                parts = line.split()
                if len(parts) >= 2 and parts[1].lstrip("*") == fname:
                    expected = parts[0].lower()
                    break
        actual = hashlib.sha256(open(archive, "rb").read()).hexdigest()
        if not expected or actual != expected:
            raise ValueError("checksum mismatch")
        log_ok("Node 运行时 SHA-256 校验通过")
    except Exception as e:
        log_err("Node 运行时 SHA-256 校验失败：%s" % e)
        try:
            os.remove(archive)
        except OSError:
            pass
        return None
    log_info("解压到 %s …" % dest_parent)
    if fname.endswith(".zip"):
        import zipfile
        with zipfile.ZipFile(archive) as z:
            z.extractall(dest_parent)
    else:
        subprocess.run(["tar", "-xf", archive, "-C", dest_parent], check=True)
    if os.path.exists(runtime_node_dir()):
        import shutil as _sh
        _sh.rmtree(runtime_node_dir(), ignore_errors=True)
    os.replace(os.path.join(dest_parent, inner), runtime_node_dir())
    try:
        os.remove(archive)
    except OSError:
        pass
    if node_ok(node_exe(), minimum):
        return node_exe()
    return None


def ensure_npm_prefix():
    """所有 npm Agent 固定安装到 AgentBoot 自有目录。"""
    os.makedirs(NPM_PREFIX, exist_ok=True)
    return NPM_PREFIX


def prefix_bin_dirs():
    dirs = []
    if POSIX:
        dirs.append(os.path.join(NPM_PREFIX, "bin"))
    else:
        dirs.append(NPM_PREFIX)
        ap = os.environ.get("APPDATA")
        if ap:
            dirs.append(os.path.join(ap, "npm"))
        if os.path.isdir(runtime_node_dir()):
            dirs.append(runtime_node_dir())
    return [d for d in dirs if os.path.isdir(d)]


def shim_bin_dir():
    """Agent 命令 shim 的安装目录。

    优先 /usr/local/bin：它默认就在所有 shell 的 PATH 上，装完当前终端
    立即可用，不需要 source ~/.bashrc——一键安装体验的关键。root 直接可写；
    非 root 但有 passwordless sudo 也行（写入时经 sudo 落盘）。
    两者都不满足时退回 ~/.agentboot/bin，由 ensure_path_registered 写
    shell 配置兜底（新终端生效）。Windows 保持 AB_HOME/bin。
    """
    if POSIX:
        candidate = "/usr/local/bin"
        try:
            if os.path.isdir(candidate) and (os.access(candidate, os.W_OK)
                                             or _sudo_usable()):
                return candidate
        except OSError:
            pass
    return os.path.join(AB_HOME, "bin")


_SUDO_CACHE = {"checked": None}


def _sudo_usable():
    """passwordless sudo 是否可用（-n 非交互，绝不弹密码提示）。

    结果按进程缓存：sudo  availability 不会在一次运行内变化，而 shim 目录
    选择在安装/卸载链路里会被多次问到，不缓存会反复 spawn sudo 进程。
    """
    if _SUDO_CACHE["checked"] is None:
        try:
            _SUDO_CACHE["checked"] = subprocess.run(
                ["sudo", "-n", "true"], capture_output=True,
                timeout=10).returncode == 0
        except Exception:
            _SUDO_CACHE["checked"] = False
    return _SUDO_CACHE["checked"]


def _ensure_bin_dir(bin_dir):
    """确保 shim 目录存在；/usr/local/bin + sudo 场景下允许创建失败（sudo 侧已存在）。"""
    try:
        os.makedirs(bin_dir, exist_ok=True)
        return True
    except OSError:
        return bin_dir == "/usr/local/bin" and _sudo_usable()


def _write_executable(path, content):
    """写一个可执行 shim。目标目录不可写但有 passwordless sudo 时，经
    sudo install 落盘到 /usr/local/bin（所有 shell 默认在 PATH 上）。
    返回是否成功。"""
    dest_dir = os.path.dirname(path)
    try:
        if os.access(dest_dir, os.W_OK):
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(content)
            os.chmod(path, 0o755)
            return True
    except OSError:
        pass
    if dest_dir == "/usr/local/bin" and _sudo_usable():
        import tempfile
        fd, tmp = tempfile.mkstemp(prefix=".agentboot-shim-")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(content)
            result = subprocess.run(["sudo", "-n", "install", "-m", "755", tmp, path],
                                    capture_output=True, text=True, timeout=60)
            return result.returncode == 0
        except Exception:
            return False
        finally:
            try:
                os.unlink(tmp)
            except OSError:
                pass
    return False


def shim_bin_dirs():
    """所有可能的 shim 目录（当前首选 + 历史回落位 + 官方安装器落盘点）。"""
    dirs = [shim_bin_dir(), os.path.join(AB_HOME, "bin")]
    dirs += user_local_bin_dirs()
    return [d for d in dirs if d]


def _shim_exec_target(path):
    """解析一个 AgentBoot shim 的 exec 目标。

    兼容两种 shim 形态：POSIX 的 `exec "..." "$@"` 行，以及 Windows .cmd 的
    `"..." %*` 调用行——只认后者会让 Windows 上的重装兜底（沿旧 shim 找真身）
    永远解析失败。"""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError:
        return None
    m = re.search(r'^\s*exec\s+"([^"]+)"', text, re.M)
    if not m:
        m = re.search(r'^\s*"([^"]+)"\s+%\*\s*$', text, re.M)
    return m.group(1) if m else None


def user_local_bin_dirs():
    """用户级安装器的标准落盘目录（POSIX）。

    官方脚本安装器（coco 等）把命令装到 ~/.local/bin 并只写 shell rc——
    当前进程的 PATH 未必包含它（rc 只对新终端生效）。装后校验必须主动
    搜索这些目录，否则安装明明成功却误报「未在 PATH 找到」：
    coco v1.0.0 实测——官方安装器退出码 0、shim 落在 ~/.local/bin、
    rc 也写了，resolve_shim_target 搜不到 → 汇总里 coco 被判失败。
    """
    if not POSIX:
        return []
    return [os.path.join(os.path.expanduser("~"), ".local", "bin")]


def resolve_shim_target(name):
    """解析 shim 应指向的「真实可执行文件」。

    绝不返回 AgentBoot 自己写的 shim：find_bin 先搜 shim 目录，重装时会把
    旧 shim 当真身返回，新 shim 再 exec 旧 shim → 死循环（v1.5.1 实测踩坑）。
    解析顺序：
      1) npm prefix bin（在线安装的真身就在这）+ 离线 payload 目录
      1.5) 用户级标准 bin 目录（~/.local/bin，官方脚本安装器的落点；
          只写 rc 不进当前 PATH，不主动搜就会误判安装失败）
      2) PATH 上的其它位置（跳过自身 shim 目录）
      3) 旧 shim 的 exec 目标（带环保护，目标仍位于 shim 目录则放弃）
    """
    cands = [name + (".cmd" if not POSIX else "")] if not POSIX else [name]
    my_dirs = shim_bin_dirs()

    def _not_mine(p):
        return bool(p) and not any(_inside(p, d) for d in my_dirs)

    for d in prefix_bin_dirs() + user_local_bin_dirs():
        for c in cands:
            p = os.path.join(d, c)
            if os.path.isfile(p):
                return p
    which = shutil.which(name)
    if _not_mine(which):
        return which
    for d in my_dirs:
        for c in cands:
            p = os.path.join(d, c)
            if os.path.isfile(p):
                target = _shim_exec_target(p)
                if target and os.path.exists(target) and _not_mine(target):
                    return target
    return None


def find_bin(name):
    cands = [name + (".cmd" if not POSIX else "")] if not POSIX else [name]
    for d in shim_bin_dirs() + prefix_bin_dirs():
        for c in cands:
            p = os.path.join(d, c)
            if os.path.exists(p):
                return p
    return shutil.which(name)


def _inside(path, parent):
    if not path:
        return False
    try:
        return os.path.commonpath([os.path.abspath(path), os.path.abspath(parent)]) == os.path.abspath(parent)
    except (OSError, ValueError):
        return False


def _npm_package_name(spec):
    """去掉 npm 版本限定；保留 @scope/name。"""
    if not spec:
        return ""
    if spec.startswith("@"):
        slash = spec.find("/")
        version = spec.find("@", slash + 1)
        return spec[:version] if version >= 0 else spec
    return spec.split("@", 1)[0]


def detect_install(a):
    """返回安装归属；绝不把 PATH 上的同名外部命令冒充为 AgentBoot 安装。"""
    if not _valid_agent_id(a.get("id")) or not _valid_bin_name(a.get("bin")):
        return {"status": "invalid", "managed": False, "source": None, "entry": {}}
    entry = load_install_state()["agents"].get(a["id"])
    if entry:
        return {"status": "managed", "managed": True,
                "source": entry.get("source"), "entry": entry}
    offline_dir = os.path.join(AGENTS_DIR, a["id"])
    if os.path.isdir(offline_dir):
        return {"status": "legacy", "managed": True, "source": "offline", "entry": {}}
    found = find_bin(a.get("bin") or "")
    if found and (_inside(found, NPM_PREFIX) or any(_inside(found, d) for d in shim_bin_dirs())):
        entry = {"executable": found}
        if _inside(found, NPM_PREFIX):
            entry["prefix"] = NPM_PREFIX
        return {"status": "legacy", "managed": True, "source": "online", "entry": entry}
    if a["id"] == "coco" and os.path.isdir(os.path.expanduser("~/.coco")):
        coco_shim = os.path.join(shim_bin_dir(), "coco" + ("" if POSIX else ".cmd"))
        if os.path.exists(coco_shim):
            return {"status": "legacy", "managed": True, "source": "online",
                    "entry": {"executable": coco_shim}}
    if a["id"] == "cursor" and os.path.isdir(_cursor_root()):
        try:
            with open(_cursor_marker(), "r", encoding="utf-8") as source:
                marker = json.load(source)
            if marker.get("managed_by") == "AgentBoot":
                return {"status": "legacy", "managed": True, "source": "online",
                        "entry": {"method": "cursor", "executable": os.path.join(
                          shim_bin_dir(), "cursor" + ("" if POSIX else ".cmd"))}}
        except (OSError, ValueError, TypeError):
            pass
    if found:
        return {"status": "external", "managed": False, "source": None,
                "entry": {}, "executable": found}
    return {"status": "absent", "managed": False, "source": None, "entry": {}}


def _remove_path(path):
    if os.path.isdir(path) and not os.path.islink(path):
        shutil.rmtree(path)
    else:
        os.remove(path)


def _remove_owned_file(path):
    """删除 AgentBoot 自己写的 shim/启动器，兼容 /usr/local/bin + sudo 场景。

    v1.5.1 起 shim 优先装 /usr/local/bin（非 root 经 sudo -n install 落盘）；
    卸载必须对称——直接 os.remove 在非 root 下抛 PermissionError，
    导致卸载失败且命令残留（实测 opencode 卸载报
    Errno 13 Permission denied: /usr/local/bin/opencode）。
    """
    try:
        _remove_path(path)
        return
    except PermissionError:
        pass
    if os.path.dirname(os.path.abspath(path)) == "/usr/local/bin" and _sudo_usable():
        result = subprocess.run(["sudo", "-n", "rm", "-f", path],
                                capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            return
    _remove_path(path)  # 再抛一次，让调用方的错误处理原样 surfaced


def _safe_extract_tar(archive, destination):
    """Extract after rejecting traversal, device nodes, and escaping links."""
    import tarfile
    root = os.path.realpath(destination)
    os.makedirs(root, exist_ok=True)
    for member in archive.getmembers():
        target = os.path.realpath(os.path.join(root, member.name))
        if not _inside(target, root):
            raise ValueError("tar 成员越界：%s" % member.name)
        if member.isdev() or member.isfifo():
            raise ValueError("tar 包含设备或管道：%s" % member.name)
        if member.issym():
            link_target = os.path.realpath(os.path.join(os.path.dirname(target), member.linkname))
            if not _inside(link_target, root):
                raise ValueError("tar 符号链接越界：%s" % member.name)
        elif member.islnk():
            link_target = os.path.realpath(os.path.join(root, member.linkname))
            if not _inside(link_target, root):
                raise ValueError("tar 硬链接越界：%s" % member.name)
    if hasattr(tarfile, "data_filter"):
        archive.extractall(root, filter="data")
    else:
        archive.extractall(root)


def _extract_tgz_fast(archive, destination):
    """系统 tar 解压 .tar.gz（C 实现，比 Python gzip 快数倍），安全校验后使用。

    先 `tar -tzf` 列出成员做越界检查，通过后才 `tar -xzf` 解压；
    任一环节失败返回 False，调用方回退 _safe_extract_tar。
    调用前提：archive 已通过 SHA-256 校验（来源可信）。
    GNU tar 会把 Windows 路径的盘符冒号当作远程主机，需 --force-local；
    bsdtar（Windows 自带）不支持该选项但也不需要——两种调用都试。"""
    import subprocess
    tar = shutil.which("tar")
    if not tar:
        return False
    try:
        listing = None
        base_cmd = None
        for pre in ([tar, "--force-local"], [tar]):
            try:
                listing = subprocess.run(pre + ["-tzf", archive], capture_output=True,
                                         text=True, errors="replace", timeout=300)
            except OSError:
                continue
            if listing.returncode == 0:
                base_cmd = pre
                break
        if not base_cmd:
            return False
        members = [line for line in listing.stdout.splitlines() if line]
        if len(members) > 20000:
            return False
        for name in members:
            norm = name.replace("\\", "/")
            if norm.startswith(("/", "\\")) or norm.startswith("../") or norm == ".." \
                    or "/../" in norm or norm.endswith("/..") or ":" in norm.split("/")[0]:
                return False
        os.makedirs(destination, exist_ok=True)
        # 不用 -C：MSYS/GNU tar 对 Windows 目标路径的解析不可靠，直接以目标目录为 cwd
        extract = subprocess.run(base_cmd + ["-xzf", archive], cwd=destination,
                                 capture_output=True, timeout=600)
        return extract.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _shim_body_owned(body, a, entry=None):
    """普通文件 shim 是否属于该 agent（官方包装脚本形态判定）。

    coco v1.1.0 官方安装器在 PATH 目录写的 web/coweb 是包装脚本：
        #!/usr/bin/env bash
        exec "/home/u/.local/bin/coco" web "$@"
    没有 AgentBoot 字样，只靠字样判定会残留（v1.8.2 InstaBox 实测）。
    认「内容引用本 agent 的 bin 名 + 指向本 agent 安装根/自己 shim」的脚本。
    """
    if not body:
        return False
    bin_name = a.get("bin") or ""
    if not bin_name or bin_name not in body:
        return False
    roots = []
    for source in (a, entry or {}):
        for key in ("install_root", "prefix", "executable"):
            val = source.get(key)
            if val:
                roots.append(os.path.realpath(os.path.expanduser(str(val))))
    roots.append(os.path.realpath(os.path.expanduser("~/.%s" % (a.get("id") or ""))))
    for d in shim_bin_dirs():
        roots.append(os.path.realpath(os.path.join(d, bin_name)))
    return any(root and root in body for root in roots)


def _shim_link_owned(path, a, entry=None):
    """软链 shim 是否指向该 agent 自己的安装根（官方安装器落点判定）。

    官方脚本安装器（coco v1.1.0）在 PATH 目录放软链指向 ~/.coco/bin/<bin>，
    软链本身不含 AgentBoot 字样，按内容判定会漏删。只认指向本 agent
    安装根（registry roots / ~/.<id>）内的链接，其余一律视为用户文件。
    """
    roots = []
    for source in (a, entry or {}):
        for key in ("install_root", "prefix"):
            val = source.get(key)
            if val:
                roots.append(os.path.realpath(os.path.expanduser(str(val))))
    # 官方安装器的惯例：~/.<id>（coco → ~/.coco）
    roots.append(os.path.realpath(os.path.expanduser("~/.%s" % (a.get("id") or ""))))
    target = os.path.realpath(path)
    return any(_inside(target, r) for r in roots if r)


def _remove_owned_shims(a, entry):
    candidates = [entry.get("executable")]
    suffix = "" if POSIX else ".cmd"
    for d in shim_bin_dirs():
        candidates.append(os.path.join(d, (a.get("bin") or "") + suffix))
    if a["id"] == "coco":
        for d in shim_bin_dirs():
            candidates += [os.path.join(d, x + suffix) for x in ("web", "coweb")]
    seen = set()
    for path in candidates:
        if not path or path in seen or not any(_inside(path, d) for d in shim_bin_dirs()):
            continue
        seen.add(path)
        try:
            if os.path.islink(path):
                # 官方脚本安装器（coco v1.1.0 起）写的是指向 ~/.coco/bin 的软链，
                # 没有 AgentBoot 字样——按软链目标是否在 agent 安装根内判定归属。
                if not _shim_link_owned(path, a, entry):
                    log_info(t("menu.uninstall_shim_changed") % path)
                    continue
                _remove_owned_file(path)
                continue
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                marker = f.read(512)
            if "AgentBoot" not in marker and not _shim_body_owned(marker, a, entry):
                log_info(t("menu.uninstall_shim_changed") % path)
                continue
            _remove_owned_file(path)
        except (FileNotFoundError, IsADirectoryError):
            pass


def _remove_coco(purge=False):
    root = os.path.expanduser("~/.coco")
    if not os.path.exists(root):
        return
    if os.path.islink(root) or not _inside(os.path.realpath(root), os.path.realpath(os.path.expanduser("~"))):
        raise OSError("拒绝删除符号链接或用户目录之外的 CoCo 路径：%s" % root)
    if purge:
        shutil.rmtree(root)
        return
    if not any(os.path.exists(os.path.join(root, name)) for name in ("bin", "runtime", "resources")):
        raise OSError("CoCo 程序目录缺少预期结构，拒绝自动删除：%s" % root)
    # CoCo 的 agent/ 内含会话、认证与用户设置；默认只移除程序文件。
    for name in os.listdir(root):
        if name == "agent":
            continue
        _remove_path(os.path.join(root, name))


def _remove_coco_external_launchers(entry):
    executable = entry.get("executable")
    if not executable:
        return
    directory = os.path.dirname(os.path.abspath(executable))
    allowed_dirs = {os.path.realpath(os.path.expanduser("~/.local/bin")), "/usr/local/bin"}
    if os.path.realpath(directory) not in allowed_dirs:
        return
    coco_root = os.path.realpath(os.path.expanduser("~/.coco"))
    suffix = ".cmd" if not POSIX else ""
    for name in ("coco", "web", "coweb"):
        path = os.path.join(directory, name + suffix)
        if not os.path.lexists(path):
            continue
        owned = False
        if os.path.islink(path):
            owned = _inside(os.path.realpath(path), coco_root)
        elif os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as source:
                    owned = ".coco" in source.read(1024)
            except OSError:
                pass
        if owned:
            _remove_owned_file(path)


def _clean_npm_prefix_residue(prefix, package):
    """清掉 npm uninstall 在 AgentBoot prefix 里的残留：包目录 + 空 scope 壳。

    实测 npm uninstall -g @scope/pkg --prefix P 删掉包本身后，会留下空的
    scope 父目录（@qwen-code/、@anthropic-ai/），用户看 node_modules
    以为没卸干净。只清理 prefix 位于 AgentBoot 自己 HOME 内（或等于
    NPM_PREFIX）时的目标包目录，绝不碰外部 prefix。
    """
    if not prefix or not package:
        return
    if not (_inside(prefix, AB_HOME) or prefix == NPM_PREFIX):
        return
    root = os.path.join(prefix, "lib", "node_modules")
    pkg_dir = os.path.join(root, package)
    if not os.path.realpath(pkg_dir).startswith(os.path.realpath(root) + os.sep):
        return
    shutil.rmtree(pkg_dir, ignore_errors=True)
    if package.startswith("@"):
        scope_dir = os.path.dirname(pkg_dir)
        try:
            if os.path.isdir(scope_dir) and not os.listdir(scope_dir):
                os.rmdir(scope_dir)
        except OSError:
            pass


def uninstall_one(a, purge=False):
    """安全卸载一个 Agent；返回 (成功, 面向用户的说明)。"""
    if not _valid_agent_id(a.get("id")) or not _valid_bin_name(a.get("bin")):
        return False, t("menu.uninstall_invalid_id")
    detected = detect_install(a)
    if not detected["managed"]:
        if detected["status"] == "external":
            return False, t("menu.uninstall_external")
        return False, t("menu.uninstall_nothing") % a["name"]

    entry = detected.get("entry") or {}
    source = detected.get("source")
    method = entry.get("method") or a.get("method", "npm")
    if a["id"] == "coco":
        try:
            _remove_coco(purge)
            _remove_coco_external_launchers(entry)
        except OSError as e:
            return False, str(e)
    elif method == "cursor":
        try:
            _remove_cursor_install()
        except OSError as e:
            return False, str(e)
    elif source == "offline":
        try:
            shutil.rmtree(os.path.join(AGENTS_DIR, a["id"]), ignore_errors=False)
        except FileNotFoundError:
            pass
        except OSError as e:
            return False, str(e)
    elif method == "npm":
        npm = npm_cmd()
        package = _npm_package_name(entry.get("package") or a.get("npm"))
        if not npm or not package:
            return False, t("menu.uninstall_no_tool") % "npm"
        cmd = [npm, "uninstall", "-g", package]
        prefix = entry.get("prefix")
        if prefix and (_inside(prefix, AB_HOME) or prefix == NPM_PREFIX):
            cmd += ["--prefix", prefix]
        log_info("$ %s" % " ".join(cmd))
        code, _output = _run_npm_process(cmd, child_env())
        if code != 0:
            return False, t("menu.uninstall_command_failed") % package
        # npm uninstall 对 @scope/pkg 只删包本身，会留下空的 scope 父目录
        # （实测 @qwen-code/、@anthropic-ai/ 残留，用户看 node_modules
        # 以为没卸干净）：显式清理包目录与空 scope 壳，只动 AgentBoot
        # 自己的 prefix。
        _clean_npm_prefix_residue(prefix, package)
    elif method == "pip":
        py = find_python()
        package = entry.get("package") or a.get("pip")
        if not py or not package:
            return False, t("menu.uninstall_no_tool") % "Python/pip"
        cmd = [py, "-m", "pip", "uninstall", "-y", package]
        log_info("$ %s" % " ".join(cmd))
        code = run_with_timeout(cmd, env=child_env(), timeout=PIP_TIMEOUT, label="pip 卸载 ")
        if code != 0:
            return False, t("menu.uninstall_command_failed") % package
    elif method == "venv":
        pass
    else:
        return False, t("menu.uninstall_manual_script")

    try:
        offline_dir = os.path.join(AGENTS_DIR, a["id"])
        if os.path.lexists(offline_dir):
            _remove_path(offline_dir)
        _remove_owned_shims(a, entry)
        forget_install(a["id"])
    except OSError as e:
        return False, str(e)
    return True, t("menu.uninstall_ok") % a["name"]


def uninstall_agents(ids, purge=False):
    """批量卸载，去重且继续处理后续项；返回失败 id。"""
    by_id = {a["id"]: a for a in load_registry()}
    # 即使自定义注册条目已删除，安装快照仍可支持安全的 npm/pip 卸载。
    for aid, entry in load_install_state()["agents"].items():
        if aid in by_id:
            continue
        a = {"id": aid, "name": entry.get("name") or aid,
             "bin": entry.get("bin"), "method": entry.get("method"), "custom": True}
        package = entry.get("package")
        if entry.get("method") == "npm":
            a["npm"] = package
        elif entry.get("method") == "pip":
            a["pip"] = package
        elif entry.get("method") == "script":
            a["script"] = package
        by_id[aid] = a
    ok_list, fail_list, seen = [], [], set()
    for aid in ids:
        if aid in seen:
            continue
        seen.add(aid)
        a = by_id.get(aid)
        if not a:
            log_err(t("menu.unknown_agent") % aid)
            fail_list.append(aid)
            continue
        ok, message = uninstall_one(a, purge=purge)
        (log_ok if ok else log_err)(message)
        (ok_list if ok else fail_list).append(aid)
    print("\n" + t("menu.uninstall_summary") %
          (", ".join(ok_list) or "-", ", ".join(fail_list) or "-"))
    if ok_list and not purge:
        print(t("menu.uninstall_preserved"))
    return fail_list


# ---------------------------------------------------------------- 在线安装

NPM_INSTALL_TIMEOUT = 900   # 单次 npm 安装整体超时（秒）
SCRIPT_INSTALL_TIMEOUT = 1800   # 官方脚本安装器（coco/hermes 等）整体超时（秒）
POSTINSTALL_TIMEOUT = 1800      # hermes postinstall（git/uv/pip 混合）超时（秒）
PIP_TIMEOUT = 900               # pip 安装/卸载超时（秒）
BUILD_TIMEOUT = 2400            # 离线包构建超时（秒）：构建含下载，10-20 分钟属正常
NPM_FETCH_FLAGS = ["--fetch-timeout=120000", "--fetch-retries=4",
                   "--fetch-retry-mintimeout=10000", "--fetch-retry-maxtimeout=60000"]


def _kill_process_tree(process):
    """超时后清理子进程树。

    安全约束（曾因 killpg(0) 误伤自身进程组而挂死）：
    pgid 为 0、不存在、或与当前进程同组时绝不 killpg，退化为 kill 单进程。
    """
    pid = getattr(process, "pid", None)
    if not pid or pid == os.getpid():
        return
    if not POSIX:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    import signal
    try:
        pgid = os.getpgid(pid)
    except OSError:
        pgid = None          # 进程已退出
    if pgid and pgid != os.getpgrp():
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(pgid, sig)
            except OSError:
                return
            try:
                process.wait(timeout=10)
                return
            except Exception:
                continue
        return
    try:
        process.kill()
    except Exception:
        pass


def run_with_timeout(cmd, env=None, timeout=NPM_INSTALL_TIMEOUT, label=""):
    """带超时与进程树清理的子进程执行（网络类命令防无限挂起）。

    背景（v1.8.2 排查）：hermes 安装流、npm/pip 卸载、官方脚本安装器等
    调用点此前用裸 subprocess.run——网络挂起时菜单无限等待，用户只能
    kill。npm_install 早就有 NPM_INSTALL_TIMEOUT + 进程树清理，其余
    网络类调用点一律补上同等保护。返回 returncode；超时返回 None
    （调用方的 != 0 / == 0 判断天然把 None 当失败）。
    """
    try:
        kwargs = {}
        if not POSIX:
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        else:
            kwargs["start_new_session"] = True   # 独立进程组，超时能整树清理
        process = subprocess.Popen(cmd, env=env, **kwargs)
    except Exception as error:
        log_err("%s启动失败：%s" % (label, error))
        return 1
    try:
        return process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        _kill_process_tree(process)
        log_err("%s执行超时（超过 %d 秒），已终止进程树" % (label or "命令", timeout))
        return None


def _run_npm_process(cmd, env):
    """执行 npm 命令：整体超时保护 + 超时清理整棵进程树。

    网络抖动时 npm 可能长时间无响应；不设超时会让安装菜单无限挂起。
    交互终端下每 15s 显示一次已耗时（npm --progress=false 全程静默，
    没有任何反馈会让用户以为卡死）。返回 (returncode, 输出尾部)；超时返回 (None, "")。"""
    import tempfile
    out_file = tempfile.TemporaryFile(mode="w+b")
    err_file = tempfile.TemporaryFile(mode="w+b")
    try:
        kwargs = {"stdout": out_file, "stderr": err_file}
        if not POSIX:
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        else:
            kwargs["start_new_session"] = True
        process = subprocess.Popen(cmd, env=env, **kwargs)

        ticker_stop = threading.Event()
        interactive = False
        try:
            interactive = sys.stdin.isatty() and sys.stdout.isatty()
        except Exception:
            pass

        def _tick():
            start = time.time()
            while not ticker_stop.wait(15):
                try:
                    sys.stdout.write("\r· npm 运行中… %d秒   " % int(time.time() - start))
                    sys.stdout.flush()
                except Exception:
                    return

        if interactive:
            threading.Thread(target=_tick, daemon=True).start()

        try:
            code = process.wait(timeout=NPM_INSTALL_TIMEOUT)
        except subprocess.TimeoutExpired:
            ticker_stop.set()
            _kill_process_tree(process)
            log_err("npm 执行超时（超过 %d 分钟），已终止进程树" % (NPM_INSTALL_TIMEOUT // 60))
            return None, ""
        finally:
            ticker_stop.set()
        if interactive:
            try:
                sys.stdout.write("\r" + " " * 30 + "\r")
                sys.stdout.flush()
            except Exception:
                pass

        def tail(stream):
            stream.flush()
            size = stream.tell()
            stream.seek(max(0, size - 4000))
            return stream.read().decode("utf-8", "replace").strip()
        return code, (tail(err_file) or tail(out_file))
    finally:
        out_file.close()
        err_file.close()


def npm_install(pkg, minimum=None, context=None):
    packages = [pkg] if isinstance(pkg, str) else list(pkg)
    if not packages:
        return True
    context = context if context is not None else {}
    versions = context.setdefault("node_versions", {})
    npm = npm_cmd(minimum, versions)
    if not npm:
        got = ensure_node(minimum)
        if not got:
            log_err("需要 Node.js %s（无法自动部署，请检查网络）" % (minimum or ">=18"))
            return False
        versions.clear()
        npm = npm_cmd(minimum, versions)
    if not npm:
        log_err("Node 已就绪但未找到匹配的 npm")
        return False
    ensure_npm_prefix()
    cmd = [npm, "install", "-g"] + packages + ["--prefix", NPM_PREFIX,
           "--no-audit", "--no-fund", "--prefer-offline",
           "--progress=false", "--loglevel=error"] + NPM_FETCH_FLAGS
    if "cn" not in context:
        context["cn"] = cn_mode()
    if context["cn"]:
        cmd += ["--registry", npm_registry(context["cn"])]
    log_info("$ %s" % " ".join(cmd))
    if "env" not in context:
        context["env"] = child_env()
    for attempt in (1, 2):
        code, output = _run_npm_process(cmd, context["env"])
        if code == 0:
            return True
        if output:
            print(output[-1500:])
        if attempt == 1:
            log_err("npm 安装失败（退出码 %s），自动重试一次 …"
                    % ("超时" if code is None else code))
    return False


def install_online(ids, preset=None, versions=None):
    preset = _resolve_preset(preset)
    versions = versions or {}
    agents = load_registry()
    by_id = {a["id"]: a for a in agents}
    ok_list, fail_list = [], []
    npm_context, ready = {}, []
    for aid in ids:
        a = by_id.get(aid)
        if not a:
            log_err("未知 Agent：%s（用 2 号菜单查看可用列表）" % aid)
            fail_list.append(aid)
            continue
        print("\n" + t("menu.install_header") % (a["name"], a.get("vendor", "")))
        print("  %s" % a.get("desc", ""))
        missing = [x for x in (a.get("requires") or []) if not shutil.which(x)]
        if missing:
            log_err(t("menu.install_missing_dep") % (a["name"], " + ".join(missing)))
            fail_list.append(aid)
            continue
        os_limits = a.get("os") or []
        if os_limits and plat_id().split("-")[0] not in os_limits:
            log_err(t("menu.install_os_limit") % (a["name"], "/".join(os_limits), plat_id()))
            fail_list.append(aid)
            continue
        ready.append(a)

    npm_groups = {}
    for a in ready:
        if a.get("method", "npm") == "npm" and not a.get("special_install"):
            npm_groups.setdefault(a.get("node") or ">=18", []).append(a)
    batched = set()
    for minimum, group in npm_groups.items():
        if len(group) < 2:
            continue
        packages = [resolve_npm_spec(a, versions.get(a["id"])) for a in group]
        log_info("批量安装 %d 个 npm Agent（共用依赖解析与连接）" % len(group))
        if npm_install(packages, minimum, npm_context):
            batched.update(a["id"] for a in group)
        else:
            log_info("批量安装失败，回退逐个安装以定位问题")

    for a in ready:
        aid = a["id"]
        method = a.get("method", "npm")
        version = versions.get(aid)
        if preset and version:
            preset_version_warning(aid, version)
        ok = False
        if a.get("special_install") == "hermes":
            log_info("使用 hermes 专用安装流程（自动适配网络）")
            ok = install_hermes_special(a)
            if not ok:
                log_err("专用流程失败：可检查 Git 是否安装、或配置代理后重试")
        elif a.get("special_install") == "cursor":
            ok = install_cursor(a)
        elif method == "npm":
            spec = resolve_npm_spec(a, version)
            if version:
                log_info("按指定版本安装：%s" % spec)
            ok = aid in batched or npm_install(spec, a.get("node"), npm_context)
        elif method == "script":
            ok = install_via_script(a)
        elif method == "pip":
            ok = install_via_pip(a)
        elif method == "venv":
            ok = install_aider_venv(a)
        if ok and a.get("bin"):
            found = aider_venv_executable() if method == "venv" else resolve_shim_target(a["bin"])
            if found:
                # 原版安装（默认）：不写任何模型配置、不注入环境变量。
                # shim 始终写——它是命令进 PATH 的入口（AB_HOME/bin 在 PATH 上，
                # 而 npm prefix 的 bin 不在），与是否预置无关。
                env_extra, args_prefix = wire_agnes(a) if preset else ({}, [])
                executable = found
                if not write_online_shim(a, found, env_extra, args_prefix):
                    log_err(t("menu.install_fail") % a["name"])
                    fail_list.append(aid)
                    continue
                executable = os.path.join(shim_bin_dir(), a["bin"] + ("" if POSIX else ".cmd"))
                record_install(a, "online", executable, NPM_PREFIX if method == "npm" else None)
                log_ok(t("menu.install_ok") % (a["name"], a["bin"]))
                ok_list.append(aid)
            else:
                log_err(t("menu.install_ok_nobin") % (a["name"], a["bin"]))
                fail_list.append(aid)
        elif ok:
            log_ok(t("menu.install_done") % a["name"])
            ok_list.append(aid)
        else:
            log_err(t("menu.install_fail") % a["name"])
            fail_list.append(aid)
        for note in a.get("notes", []) or []:
            print("  ℹ %s" % note)
    print("\n" + t("menu.install_summary") %
          (", ".join(ok_list) or "-", ", ".join(fail_list) or "-"))
    if not POSIX:
        print(t("menu.install_hint_win"))
    ensure_path_registered()
    return fail_list


def _script_fallback_urls(url):
    """GitHub Pages 项目页托管脚本的 jsDelivr 兜底地址。

    bit-cook.github.io/<project>/… 由 <user>/<project> 仓库的 gh-pages 分支服务；
    github.io 不可达或自定义域名过期时，jsDelivr 直读 git 内容仍可取到脚本。"""
    from urllib.parse import urlsplit
    parsed = urlsplit(url or "")
    host = (parsed.hostname or "").lower()
    parts = [p for p in parsed.path.split("/") if p]
    if host.endswith(".github.io") and len(parts) >= 2:
        user = host[: -len(".github.io")]
        project = parts[0]
        if project != "%s.github.io" % user:
            return ["https://cdn.jsdelivr.net/gh/%s/%s@gh-pages/%s"
                    % (user, project, "/".join(parts[1:]))]
    return []


def _script_interpreter():
    """执行下载的安装脚本所用的解释器：优先 bash，缺失才回落 sh。

    历史 bug：本函数曾一律用 sh 执行，而多数官方安装脚本（coco 等）是
    bash 脚本（数组/[[ ]]/process substitution），sh（dash）在第一个 bash
    专用语法处即 Syntax error，安装必败。按脚本 shebang 的本意执行；
    Alpine 等无 bash 的环境自动回落 sh。
    """
    from shutil import which
    return "bash" if which("bash") else "sh"


def install_via_script(a):
    from urllib.parse import urlsplit
    url = a.get("script")
    parsed = urlsplit(url or "")
    if parsed.scheme.lower() != "https" or not parsed.netloc:
        log_err("安装脚本必须使用有效的 HTTPS URL")
        return False
    urls = [url] + _script_fallback_urls(url)
    if parsed.hostname in ("github.com", "raw.githubusercontent.com"):
        for p in gh_mirrors():
            urls.append(p + url)
    for u in urls:
        path = None
        try:
            path = _download_script(u, ".sh" if POSIX else ".ps1")
            cmd = ([_script_interpreter(), path] if POSIX else
                   ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path])
            log_info("执行已下载脚本：%s" % u)
            code = run_with_timeout(cmd, env=child_env(),
                                     timeout=SCRIPT_INSTALL_TIMEOUT, label="安装脚本 ")
            if code == 0:
                return True
            log_err("安装脚本执行失败，尝试下一个源 …")
        except Exception as e:
            log_err("脚本下载失败(%s)：%s" % (u, e))
        finally:
            if path:
                try:
                    os.remove(path)
                except OSError:
                    pass
    return False


def _download_script(url, suffix):
    import tempfile
    from urllib import request as urllib_request
    from urllib.parse import urlsplit
    request = urllib_request.Request(url, headers={"User-Agent": "AgentBoot/1.0"})
    fd, path = tempfile.mkstemp(prefix="agentboot-script-", suffix=suffix)
    try:
        total = 0
        with os.fdopen(fd, "wb") as output, urllib_request.urlopen(request, timeout=60) as response:
            final_url = urlsplit(response.geturl())
            if final_url.scheme.lower() != "https":
                raise ValueError("安装脚本重定向到了非 HTTPS 地址")
            while True:
                chunk = response.read(65536)
                if not chunk:
                    break
                total += len(chunk)
                if total > 4 * 1024 * 1024:
                    raise ValueError("安装脚本超过 4 MiB 限制")
                output.write(chunk)
        if total == 0:
            raise ValueError("安装脚本为空")
        return path
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.remove(path)
        except OSError:
            pass
        raise


def _download_cursor_asset(url, suffix):
    """Download one pinned official Cursor asset and return path/final-url/SHA-256."""
    import hashlib
    import tempfile
    from urllib import request as urllib_request
    from urllib.parse import urlsplit
    request = urllib_request.Request(url, headers={"User-Agent": "AgentBoot/%s" % VERSION})
    fd, path = tempfile.mkstemp(prefix="agentboot-cursor-", suffix=suffix)
    try:
        total = 0
        digest = hashlib.sha256()
        with os.fdopen(fd, "wb") as output, urllib_request.urlopen(request, timeout=180) as response:
            final = urlsplit(response.geturl())
            if final.scheme != "https" or final.hostname not in ("api2.cursor.sh", "downloads.cursor.com"):
                raise ValueError("Cursor 下载重定向到了非官方地址")
            length = int(response.headers.get("Content-Length") or 0)
            if length and length > CURSOR_MAX_BYTES:
                raise ValueError("Cursor 安装包超过大小限制")
            for chunk in iter(lambda: response.read(1 << 20), b""):
                total += len(chunk)
                if total > CURSOR_MAX_BYTES:
                    raise ValueError("Cursor 安装包超过大小限制")
                digest.update(chunk)
                output.write(chunk)
        if total < 1024 * 1024:
            raise ValueError("Cursor 安装包异常过小")
        return path, response.geturl(), digest.hexdigest()
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.remove(path)
        except OSError:
            pass
        raise


def _cursor_root():
    return os.path.join(APPS_DIR, "cursor")


def _cursor_marker(root=None):
    return os.path.join(root or _cursor_root(), "agentboot-managed.json")


def _write_cursor_marker(root, final_url, digest):
    marker = {"managed_by": "AgentBoot", "version": CURSOR_VERSION,
              "source": final_url, "sha256": digest}
    with open(_cursor_marker(root), "w", encoding="utf-8", newline="\n") as output:
        json.dump(marker, output, ensure_ascii=False, indent=2)
        output.write("\n")


def _write_cursor_shim(executable, app_bundle=None):
    bin_dir = shim_bin_dir()
    if not _ensure_bin_dir(bin_dir):
        raise ValueError("无法创建 shim 目录：%s" % bin_dir)
    if POSIX:
        path = os.path.join(bin_dir, "cursor")
        if app_bundle:
            cli = os.path.join(app_bundle, "Contents", "Resources", "app", "bin", "cursor")
            body = ('if [ -x "%s" ]; then exec "%s" "$@"; fi\n'
                    'exec open "%s" --args "$@"\n') % (cli, cli, app_bundle)
        else:
            body = 'exec "%s" "$@"\n' % executable
        if not _write_executable(path, "#!/bin/sh\n# AgentBoot Cursor launcher\n" + body):
            raise ValueError("无法写入 shim：%s" % path)
    else:
        path = os.path.join(bin_dir, "cursor.cmd")
        with open(path, "w", encoding="utf-8-sig", newline="") as output:
            output.write('@echo off\r\nrem AgentBoot Cursor launcher\r\nstart "" "%s" %%*\r\n' % executable)
    return path


def _cursor_candidate():
    root = _cursor_root()
    return root + ".new.%s" % os.getpid()


def _commit_cursor_candidate(candidate):
    root = _cursor_root()
    backup = root + ".old.%s" % os.getpid()
    shutil.rmtree(backup, ignore_errors=True)
    if os.path.isdir(root):
        os.replace(root, backup)
    try:
        os.replace(candidate, root)
        shutil.rmtree(backup, ignore_errors=True)
    except Exception:
        if os.path.isdir(backup):
            os.replace(backup, root)
        raise
    return root


def _powershell_executable():
    return shutil.which("powershell.exe") or shutil.which("pwsh.exe") or \
           shutil.which("pwsh") or shutil.which("powershell")


def _verify_cursor_windows_signature(path, shell=None):
    shell = shell or _powershell_executable()
    if not shell:
        return False
    result = subprocess.run(
        [shell, "-NoProfile", "-NonInteractive", "-Command",
         "$s=Get-AuthenticodeSignature -LiteralPath $args[0]; "
         "if($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch 'Anysphere'){exit 1}", path],
        timeout=60)
    return result.returncode == 0


def install_cursor(a):
    """Install pinned official Cursor into an AgentBoot-owned per-user directory."""
    pid = plat_id()
    url = CURSOR_DOWNLOADS.get(pid)
    if not url:
        log_err("Cursor 暂不支持当前平台：%s" % pid)
        return False
    suffix = ".AppImage" if pid.startswith("linux") else (".dmg" if pid.startswith("darwin") else ".exe")
    path = None
    candidate = _cursor_candidate()
    root = _cursor_root()
    if os.path.islink(APPS_DIR):
        log_err("Cursor 应用根目录是符号链接，拒绝安装")
        return False
    if os.path.exists(root):
        if os.path.islink(root) or not _inside(os.path.realpath(root), os.path.realpath(APPS_DIR)):
            log_err("Cursor 私有目录位于 AgentBoot 应用根目录之外，拒绝覆盖")
            return False
        try:
            with open(_cursor_marker(root), "r", encoding="utf-8") as source:
                marker = json.load(source)
        except (OSError, ValueError, TypeError):
            log_err("Cursor 私有目录缺少 AgentBoot 归属标记，拒绝覆盖")
            return False
        if marker.get("managed_by") != "AgentBoot":
            log_err("Cursor 私有目录归属标记无效，拒绝覆盖")
            return False
    shutil.rmtree(candidate, ignore_errors=True)
    try:
        log_info("下载 Cursor 官方版本 %s：%s" % (CURSOR_VERSION, url))
        path, final_url, digest = _download_cursor_asset(url, suffix)
        os.makedirs(candidate, mode=0o700, exist_ok=True)
        if pid.startswith("linux"):
            if digest != CURSOR_SHA256.get(pid):
                raise ValueError("Cursor AppImage SHA-256 校验失败（golden 渠道已重 build 该版本，"
                                 "请更新 core/menu.py 的 CURSOR_SHA256）")
            executable = os.path.join(candidate, "Cursor.AppImage")
            shutil.move(path, executable)
            path = None
            os.chmod(executable, 0o755)
            with open(executable, "rb") as source:
                if source.read(4) != b"\x7fELF":
                    raise ValueError("Cursor AppImage 不是有效 ELF 文件")
            check = subprocess.run([executable, "--appimage-version"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            if check.returncode != 0:
                raise ValueError("Cursor AppImage 自检失败")
            _write_cursor_marker(candidate, final_url, digest)
            _write_cursor_shim(os.path.join(root, "Cursor.AppImage"))
            _commit_cursor_candidate(candidate)
        elif pid.startswith("darwin"):
            mount = candidate + ".mount"
            os.makedirs(mount, exist_ok=True)
            try:
                subprocess.run(["hdiutil", "attach", "-readonly", "-nobrowse", "-mountpoint", mount, path],
                               check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
                app = os.path.join(mount, "Cursor.app")
                if not os.path.isdir(app):
                    raise ValueError("Cursor DMG 中缺少 Cursor.app")
                subprocess.run(["codesign", "--verify", "--deep", "--strict", app], check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
                subprocess.run(["spctl", "--assess", "--type", "execute", app], check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
                installed = os.path.join(candidate, "Cursor.app")
                subprocess.run(["ditto", app, installed], check=True, timeout=180)
                subprocess.run(["codesign", "--verify", "--deep", "--strict", installed], check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
                subprocess.run(["spctl", "--assess", "--type", "execute", installed], check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
            finally:
                subprocess.run(["hdiutil", "detach", mount], stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, timeout=30)
                shutil.rmtree(mount, ignore_errors=True)
            _write_cursor_marker(candidate, final_url, digest)
            _write_cursor_shim(None, os.path.join(root, "Cursor.app"))
            _commit_cursor_candidate(candidate)
        else:
            shell = _powershell_executable()
            if not shell:
                raise ValueError("缺少 PowerShell，无法验证 Cursor Authenticode 签名")
            if not _verify_cursor_windows_signature(path, shell):
                raise ValueError("Cursor Windows 安装器签名验证失败")
            shutil.rmtree(candidate, ignore_errors=True)
            command = [path, "/VERYSILENT", "/NORESTART", "/MERGETASKS=!runcode", "/DIR=%s" % candidate]
            if subprocess.run(command, timeout=300).returncode != 0:
                raise ValueError("Cursor Windows 安装器执行失败")
            executable = os.path.join(candidate, "Cursor.exe")
            if not os.path.isfile(executable):
                raise ValueError("Cursor Windows 安装目录缺少 Cursor.exe")
            if not _verify_cursor_windows_signature(executable, shell):
                raise ValueError("Cursor.exe 签名验证失败")
            _write_cursor_marker(candidate, final_url, digest)
            _write_cursor_shim(os.path.join(root, "Cursor.exe"))
            _commit_cursor_candidate(candidate)
        return True
    except Exception as error:
        log_err("Cursor 安装失败：%s" % error)
        shutil.rmtree(candidate, ignore_errors=True)
        if not os.path.exists(root):
            shim = os.path.join(shim_bin_dir(), "cursor" + ("" if POSIX else ".cmd"))
            try:
                with open(shim, "r", encoding="utf-8", errors="ignore") as source:
                    owned = "AgentBoot Cursor launcher" in source.read(256)
                if owned:
                    os.remove(shim)
            except OSError:
                pass
        return False
    finally:
        if path:
            try:
                os.remove(path)
            except OSError:
                pass


def _remove_cursor_install():
    root = _cursor_root()
    if not os.path.exists(root):
        return
    if not _inside(root, APPS_DIR) or os.path.islink(root):
        raise OSError("拒绝删除 AgentBoot 应用目录之外的 Cursor")
    try:
        with open(_cursor_marker(root), "r", encoding="utf-8") as source:
            marker = json.load(source)
    except (OSError, ValueError, TypeError):
        raise OSError("Cursor 缺少 AgentBoot 归属标记，拒绝自动删除")
    if marker.get("managed_by") != "AgentBoot":
        raise OSError("Cursor 归属标记无效，拒绝自动删除")
    if os.name == "nt":
        uninstallers = [name for name in os.listdir(root) if re.match(r"unins\d*\.exe$", name, re.I)]
        if uninstallers:
            subprocess.run([os.path.join(root, uninstallers[0]), "/VERYSILENT", "/NORESTART"], timeout=180)
    if os.path.exists(root):
        shutil.rmtree(root)


def install_via_pip(a):
    py = find_python()   # 带真实执行校验，避免命中 Windows 商店存根
    if not py:
        log_err("需要 Python 3 与 pip")
        return False
    cmd = [py, "-m", "pip", "install", a["pip"], "-U"]
    if cn_mode():
        cmd += ["-i", PIP_MIRROR]
    log_info("$ %s" % " ".join(cmd))
    return run_with_timeout(cmd, timeout=PIP_TIMEOUT, label="pip ") == 0


def aider_venv_executable():
    relative = os.path.join("Scripts", "aider.exe") if not POSIX else os.path.join("bin", "aider")
    return os.path.join(AGENTS_DIR, "aider", "venv", relative)


def install_aider_venv(a):
    py = find_python()
    if not py:
        log_err("Aider 需要 Python 3.10+")
        return False
    check = subprocess.run([py, "-c", "import sys; print('%d.%d'%sys.version_info[:2])"],
                           capture_output=True, text=True, timeout=20)
    try:
        version = tuple(int(x) for x in check.stdout.strip().split(".")[:2])
    except ValueError:
        return False
    if check.returncode or version < (3, 10):
        log_err("Aider 需要 Python 3.10+，当前 %s" % check.stdout.strip())
        return False
    root = os.path.join(AGENTS_DIR, "aider")
    candidate, backup = root + ".new.%s" % os.getpid(), root + ".old.%s" % os.getpid()
    shutil.rmtree(candidate, ignore_errors=True)
    shutil.rmtree(backup, ignore_errors=True)
    if subprocess.run([py, "-m", "venv", os.path.join(candidate, "venv")]).returncode:
        return False
    pip = os.path.join(candidate, "venv", "Scripts", "pip.exe") if not POSIX else os.path.join(candidate, "venv", "bin", "pip")
    cmd = [pip, "install", "--disable-pip-version-check", a["pip"]]
    if cn_mode(): cmd += ["-i", PIP_MIRROR]
    if run_with_timeout(cmd, env=child_env(), timeout=PIP_TIMEOUT, label="pip "):
        shutil.rmtree(candidate, ignore_errors=True)
        return False
    if os.path.isdir(root): os.replace(root, backup)
    try:
        os.replace(candidate, root)
        shutil.rmtree(backup, ignore_errors=True)
    except Exception:
        if os.path.isdir(backup) and not os.path.exists(root): os.replace(backup, root)
        raise
    return os.path.isfile(aider_venv_executable())


# ---------------------------------------------------------------- hermes-agent 国内专用安装

def _npm_global_root(env, npm=None):
    try:
        r = subprocess.run([npm or npm_cmd() or "npm", "root", "-g", "--prefix", NPM_PREFIX], capture_output=True,
                           text=True, timeout=60, env=env)
        return r.stdout.strip()
    except Exception:
        return ""


def _hermes_uv_meta(pkg_root):
    """从已安装的 uv-installer.js 解析 UV_VERSION 与当前平台的 uv 资产名/sha256。"""
    import re as _re
    path = os.path.join(pkg_root, "lib", "uv-installer.js")
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        return None, None, None
    m = _re.search(r'UV_VERSION\s*=\s*"([^"]+)"', text)
    version = m.group(1) if m else None
    if sys.platform == "win32":
        target = "aarch64-pc-windows-msvc" if platform.machine().lower() in ("arm64", "aarch64") else "x86_64-pc-windows-msvc"
        asset = "uv-%s.zip" % target
        member = "uv.exe"
    else:
        target = ("aarch64-apple-darwin" if platform.machine().lower() in ("arm64", "aarch64")
                  else "x86_64-apple-darwin") if sys.platform == "darwin" else (
                  "aarch64-unknown-linux-gnu" if platform.machine().lower() in ("arm64", "aarch64")
                  else "x86_64-unknown-linux-gnu")
        asset = "uv-%s.tar.gz" % target
        # 只要 basename：uv 发行包的包内目录名随版本变化过——旧版 <target>/uv，
        # 0.12.13 起是 uv-<target>/uv（实测 KeyError: 'x86_64-unknown-linux-gnu/uv
        # not found'）。硬编码完整成员名一改布局就炸，交给 _extract_uv_binary 按
        # basename 找，同时兼容两种布局与根级平铺。
        member = "uv"
    m = _re.search(r'"%s":\s*"([0-9a-f]{64})"' % _re.escape(asset), text)
    sha = m.group(1) if m else None
    return version, (asset, member), sha


def _download_mirror(urls, dest):
    import urllib.request
    for u in urls:
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "AgentBoot/1.0"})
            with urllib.request.urlopen(req, timeout=90) as r, open(dest, "wb") as f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
            return True
        except Exception:
            continue
    return False


def _extract_uv_binary(archive, asset, want):
    """从 uv 发行包中取出 want（uv / uv.exe）的字节；找不到返回 (None, 目录样本)。

    布局无关：uv 的包内目录名改过（旧 <target>/uv → 新 uv-<target>/uv），
    按 basename 匹配并取路径最浅的匹配项，新旧布局与根级平铺都能用。
    """
    import tarfile
    import zipfile
    best = None  # (深度, 名字)
    try:
        if asset.endswith(".zip"):
            with zipfile.ZipFile(archive) as z:
                names = z.namelist()
                for name in names:
                    base = name.rstrip("/").split("/")[-1]
                    if base != want or name.endswith("/"):
                        continue
                    depth = name.count("/")
                    if best is None or depth < best[0]:
                        best = (depth, name)
                if best is None:
                    return None, [n for n in names if n.endswith("/")][:5]
                return z.read(best[1]), None
        with tarfile.open(archive, "r:gz") as t:
            for m in t.getmembers():
                if not m.isfile() or os.path.basename(m.name) != want:
                    continue
                depth = m.name.count("/")
                if best is None or depth < best[0]:
                    best = (depth, m.name)
            if best is None:
                return None, [m.name for m in t.getmembers() if m.isdir()][:5]
            f = t.extractfile(best[1])
            if f is None:
                return None, [best[1]]
            return f.read(), None
    except (tarfile.TarError, zipfile.BadZipFile, OSError) as e:
        return None, ["解析失败：%s" % e]


def _seed_uv(pkg_root):
    """预置 uv 二进制到 <pkg>/.uv_bin 并写入 marker，绕过 postinstall 的 GitHub 直连下载。"""
    import hashlib
    import tarfile
    import zipfile
    version, asset_info, sha = _hermes_uv_meta(pkg_root)
    if not (version and asset_info and sha):
        log_err("无法解析 hermes uv 安装参数（包结构变化？），回退官方流程")
        return False
    asset, member = asset_info
    uv_dir = os.path.join(pkg_root, ".uv_bin")
    exe = os.path.join(uv_dir, "uv.exe" if sys.platform == "win32" else "uv")
    marker = os.path.join(uv_dir, "install.json")
    if os.path.exists(marker) and os.path.exists(exe):
        try:
            m = json.load(open(marker, "r", encoding="utf-8"))
            if m.get("version") == version and m.get("sha256") == sha:
                return True  # 已预置
        except Exception:
            pass
    base = "https://github.com/astral-sh/uv/releases/download/%s/%s" % (version, asset)
    urls = [base]
    for p in gh_mirrors():
        urls.append(p + base)
    os.makedirs(uv_dir, exist_ok=True)
    archive = os.path.join(uv_dir, asset)
    log_info("从镜像下载 uv %s …" % version)
    if not _download_mirror(urls, archive):
        log_err("uv 镜像下载失败")
        return False
    with open(archive, "rb") as f:
        actual_sha = hashlib.sha256(f.read()).hexdigest()
    if actual_sha != sha.lower():
        log_err("uv SHA-256 校验失败")
        try:
            os.remove(archive)
        except OSError:
            pass
        return False
    data, sample = _extract_uv_binary(archive, asset, member)
    if data is None:
        log_err("uv 发行包内未找到 %s（uv 包内布局可能又变了；包内目录样本：%s）"
                % (member, ", ".join(sample) if sample else "（空）"))
        try:
            os.remove(archive)
        except OSError:
            pass
        return False
    with open(exe, "wb") as f:
        f.write(data)
    if POSIX:
        os.chmod(exe, 0o755)
    with open(marker, "w", encoding="utf-8") as f:
        json.dump({"version": version, "asset": asset, "sha256": sha}, f, indent=2)
    try:
        os.remove(archive)
    except OSError:
        pass
    log_ok("uv 已就绪（%.1f MB，镜像预置）" % (len(data) / 1048576.0))
    return True


def _github_git_reachable():
    """探测 github.com 的 git 端点是否可用（决定 hermes 安装是否启用镜像重写）。"""
    try:
        r = subprocess.run(["git", "ls-remote", "https://github.com/NousResearch/hermes-agent.git", "HEAD"],
                           capture_output=True, timeout=30, env=child_env())
        return r.returncode == 0
    except Exception:
        return False


def install_hermes_special(a):
    """hermes-agent：分步安装（包体 → uv 预置 → postinstall，git/Python/PyPI 自动适配网络）。"""
    # 1) 包体（跳过会直连 GitHub 的 postinstall）
    npm = npm_cmd(a.get("node"))
    if not npm:
        if not ensure_node(a.get("node")):
            log_err("Hermes 需要 Node.js %s" % (a.get("node") or ">=20"))
            return False
        npm = npm_cmd(a.get("node"))
    if not npm:
        return False
    ensure_npm_prefix()
    cmd = [npm, "install", "--ignore-scripts", "-g", a["npm"],
           "--prefix", NPM_PREFIX, "--no-audit", "--no-fund", "--prefer-offline",
           "--progress=false", "--loglevel=error"]
    if cn_mode():
        cmd += ["--registry", npm_registry()]
    log_info("$ %s" % " ".join(cmd))
    env = child_env()
    code, _output = _run_npm_process(cmd, env)
    if code != 0:
        return False
    root = _npm_global_root(env, npm)
    pkg_root = os.path.join(root, "hermes-agent")
    if not os.path.isdir(pkg_root):
        log_err("未定位到 hermes-agent 包目录")
        return False
    # 2) 预置 uv（官方地址优先，镜像兜底）。失败不阻断：官方 postinstall 的
    #    ensureUv 会自行下载（uv 布局变化/单镜像抖动时尤其应该放行），
    #    由官方流程给出最终成败，而不是在这里误判为安装失败。
    if not _seed_uv(pkg_root):
        log_info("uv 预置未完成，继续官方 postinstall 流程")
    # 3) 执行官方 postinstall：git 不可达时启用镜像重写；Python/PyPI 镜像对全球用户同样可用
    env = child_env()
    gh_prefixes = gh_mirrors()
    if not _github_git_reachable():
        if gh_prefixes:
            log_info("github.com git 端点不可达：启用镜像重写（%s）" % gh_prefixes[0])
            env.update({
                "GIT_CONFIG_COUNT": "1",
                "GIT_CONFIG_KEY_0": "url.%shttps://github.com/.insteadOf" % gh_prefixes[0],
                "GIT_CONFIG_VALUE_0": "https://github.com/",
            })
    uv_mirror = (gh_prefixes[0] if gh_prefixes else "") \
        + "https://github.com/astral-sh/python-build-standalone/releases/download"
    env.update({
        "UV_PYTHON_INSTALL_MIRROR": uv_mirror,
        "UV_HTTP_TIMEOUT": "180",
    })
    node = node_exe() if _inside(npm, runtime_node_dir()) else shutil.which("node")
    if not node or not node_ok(node, a.get("node")):
        log_err("Hermes postinstall 未找到满足版本的 Node")
        return False
    script = os.path.join(pkg_root, "scripts", "postinstall.js")
    code = run_with_timeout([node, script], env=env,
                            timeout=POSTINSTALL_TIMEOUT, label="Hermes postinstall ")
    return code == 0


# ---------------------------------------------------------------- 离线安装

def fixup_hermes_venv(payload_plat_dir, dst_nm):
    """hermes 离线载荷：三变体路径替换（原始/JSON 转义/正斜杠）+ 生成直调入口 runpy。

    载荷在打包机完成 postinstall（含 venv），但 venv 的 .exe 启动器内嵌打包机绝对路径
    无法搬移，因此安装后改写 pyvenv.cfg / editable finder / 状态文件的路径，
    并用 venv python 直调 hermes_cli.main 的 runpy 绕过 .exe 启动器。
    """
    marker = os.path.join(payload_plat_dir, "PACK_ROOT.txt")
    if not os.path.exists(marker):
        log_err("hermes 载荷缺少 PACK_ROOT.txt（旧版载荷），跳过 venv 路径修复")
        return
    old_root = open(marker, "r", encoding="utf-8").read().strip().rstrip("\\/")
    new_root = os.path.join(dst_nm, "hermes-agent")
    old_variants = [old_root, old_root.replace("\\", "\\\\"), old_root.replace("\\", "/")]
    new_variants = [new_root, new_root.replace("\\", "\\\\"), new_root.replace("\\", "/")]
    text_ext = {".json", ".cfg", ".txt", ".cmd", ".sh", ".ps1", ".py", ".js", ".mjs", ".cjs",
                ".ini", ".toml", ".yaml", ".yml", ".md", ".bat", ".nu", ""}
    names = {"activate", "activate.bat", "activate.csh", "activate.fish", "activate.nu"}
    fixed = 0
    for base, _dirs, files in os.walk(dst_nm):
        for fn in files:
            p = os.path.join(base, fn)
            ext = os.path.splitext(fn)[1].lower()
            if ext not in text_ext and fn not in names:
                continue
            try:
                if os.path.getsize(p) > 3 * 1024 * 1024:
                    continue
                t = open(p, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            if not any(v in t for v in old_variants):
                continue
            for v, nv in zip(old_variants, new_variants):
                t = t.replace(v, nv)
            with open(p, "w", encoding="utf-8", newline="") as f:
                f.write(t)
            fixed += 1
    log_ok("hermes 离线路径修复：%d 个文件" % fixed)

    # 直调入口 runpy（绕过内嵌绝对路径的 .exe 启动器）
    runpy = os.path.join(AGENTS_DIR, "hermes", "hermes-run.py")
    with open(runpy, "w", encoding="utf-8", newline="\n") as f:
        f.write("import sys\nfrom hermes_cli.main import main\nsys.exit(main())\n")


def coco_offline_install(a, payload, preset=None):
    """CoCo 离线安装（Linux/macOS）：本地复刻官方安装步骤，不联网。

    preset=False（默认，原版）：只装官方发行包，不写 auth/settings，
    CoCo 首次运行时走自己的模型配置流程。
    preset=True：额外写入 Agnes 密钥与默认模型设置。
    """
    preset = _resolve_preset(preset)
    import hashlib
    import tarfile
    coco_version = str(a.get("coco_version") or "1.1.0")
    tgz = os.path.join(payload, "coco-%s.tgz" % coco_version)
    side = tgz + ".sha256"
    key_file = os.path.join(payload, "agnes.key")
    required = [tgz, side] + ([key_file] if preset else [])
    if not all(os.path.exists(p) for p in required):
        log_err("CoCo 离线载荷不完整（缺 coco-%s.tgz / .sha256%s）"
                % (coco_version, " / agnes.key" if preset else ""))
        return False
    with open(side, "r", encoding="utf-8") as source:
        expected = source.read().split()[0].lower()
    hasher = hashlib.sha256()
    with open(tgz, "rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            hasher.update(chunk)
    h = hasher.hexdigest()
    if h != expected:
        log_err("CoCo 发行包 SHA-256 校验失败")
        return False
    log_ok("CoCo 发行包校验通过")

    home = os.path.expanduser("~")
    install_dir = os.path.join(home, ".coco")
    bin_dir = shim_bin_dir()
    if not _ensure_bin_dir(bin_dir):
        raise ValueError("无法创建 shim 目录：%s" % bin_dir)

    # Node：系统 >=22.19 优先，否则用载荷内置 Node 22.23.2
    def _node_ok(p):
        try:
            out = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=15)
            major, minor = re.match(r"v?(\d+)\.(\d+)", out.stdout.strip()).groups()
            return (int(major), int(minor)) >= (22, 19)
        except Exception:
            return False

    node_bin = shutil.which("node")
    node_archive = None
    if node_bin and _node_ok(node_bin):
        log_ok("使用系统 Node")
    else:
        ntgz = next((os.path.join(payload, f) for f in os.listdir(payload)
                     if f.startswith("node-v") and f.endswith(".tar.gz")), None)
        if not ntgz:
            log_err("系统 Node 过旧且载荷无内置 Node 运行时")
            return False
        node_archive = ntgz

    # 备份用户 agent 配置 → 换新发行包 → 还原配置
    agent_dir = os.path.join(install_dir, "agent")
    # 备份必须放在 install_dir 外；否则随后删除 ~/.coco 会一并删掉备份。
    backup = install_dir + ".agent.agentboot-bak"
    had_agent = os.path.isdir(agent_dir)
    if os.path.exists(backup):
        shutil.rmtree(backup, ignore_errors=True)
    if had_agent:
        shutil.move(agent_dir, backup)
    if os.path.exists(install_dir):
        shutil.rmtree(install_dir)
    extract = install_dir + ".extract"
    if os.path.isdir(extract):
        shutil.rmtree(extract)
    os.makedirs(extract, exist_ok=True)
    if not _extract_tgz_fast(tgz, extract):
        with tarfile.open(tgz, "r:gz") as t:
            _safe_extract_tar(t, extract)
    try:
        os.replace(os.path.join(extract, "package"), install_dir)
        shutil.rmtree(extract, ignore_errors=True)
        if had_agent:
            shutil.move(backup, agent_dir)
    except Exception:
        if had_agent and os.path.isdir(backup) and not os.path.exists(agent_dir):
            os.makedirs(install_dir, exist_ok=True)
            shutil.move(backup, agent_dir)
        raise
    os.makedirs(os.path.join(agent_dir, "sessions"), exist_ok=True)
    os.makedirs(os.path.join(agent_dir, "languages"), exist_ok=True)

    if node_archive:
        runtime = os.path.join(install_dir, "runtime")
        shutil.rmtree(runtime, ignore_errors=True)
        os.makedirs(runtime, exist_ok=True)
        if not _extract_tgz_fast(node_archive, runtime):
            with tarfile.open(node_archive, "r:gz") as archive:
                _safe_extract_tar(archive, runtime)
        children = [name for name in os.listdir(runtime) if name != "node"]
        if len(children) != 1 or not os.path.isdir(os.path.join(runtime, children[0])):
            raise ValueError("CoCo Node 载荷结构无效")
        os.replace(os.path.join(runtime, children[0]), os.path.join(runtime, "node"))
        node_bin = os.path.join(runtime, "node", "bin", "node")
        if not os.path.isfile(node_bin):
            raise ValueError("CoCo Node 入口缺失")
        os.chmod(node_bin, 0o755)
        log_ok("使用载荷内置 Node：%s" % node_bin)

    # 写配置：models 骨架 + Agnes 密钥 + 默认设置
    registry_path = os.path.join(install_dir, "resources", "provider-registry.v1.json")
    providers = {}
    if os.path.exists(registry_path):
        reg = json.load(open(registry_path, "r", encoding="utf-8"))
        for pid_, entry in (reg.get("providers") or {}).items():
            providers[pid_] = {k: entry[k] for k in ("api", "authHeader", "baseUrl", "compat") if k in entry}
            providers[pid_]["models"] = []
    def _write_json(path, obj):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
        os.chmod(path, 0o600)
    models_path = os.path.join(agent_dir, "models.json")
    if not os.path.exists(models_path):
        _write_json(models_path, {"providers": providers})
    # auth/settings 属于「预置模型」：仅 preset=True 时写入；
    # 原版安装（默认）不写，CoCo 首次运行时走自己的模型配置流程
    if preset:
        auth_path = os.path.join(agent_dir, "auth.json")
        if not os.path.exists(auth_path):
            with open(key_file, "r", encoding="utf-8") as source:
                agnes_key = source.read().strip()
            _write_json(auth_path, {"agnes": {"type": "api_key", "key": agnes_key}})
        settings_path = os.path.join(agent_dir, "settings.json")
        if not os.path.exists(settings_path):
            _write_json(settings_path, {"defaultProvider": "agnes", "defaultModel": "agnes-2.5-flash",
                                        "defaultThinkingLevel": "max"})
        log_ok("已预置 Agnes 免费模型（~/.coco/agent/auth.json + settings.json）")

    # 命令 shim（AgentBoot 管理的 bin 目录，已在 PATH）
    for name, arg in (("coco", ""), ("web", " web"), ("coweb", " web")):
        shim = os.path.join(bin_dir, name)
        if not _write_executable(shim, "#!/bin/sh\n# AgentBoot shim for coco\nexec \"%s\" \"%s\"%s \"$@\"\n" %
                                 (node_bin, os.path.join(install_dir, "bin", "coco"), arg)):
            raise ValueError("无法写入 shim：%s" % shim)
    suffix = "（预置 Agnes 免费模型）" if preset else "（原版安装，首次运行时自选模型）"
    log_ok("%s 离线安装完成，命令：coco / web / coweb%s" % (a["name"], suffix))
    return True


def find_payload_dir(explicit=None):
    cands = []
    if explicit:
        cands.append(explicit)
    env_p = os.environ.get("AGENTBOOT_PAYLOAD")
    if env_p:
        cands.append(env_p)
    cands += [os.path.join(APP_DIR, "payloads"), os.path.join(os.getcwd(), "payloads")]
    for c in cands:
        if c and os.path.isdir(os.path.join(c, "agents")):
            return c
    return None


def offline_install(ids, payload_dir=None, preset=None):
    preset = _resolve_preset(preset)
    pdir = find_payload_dir(payload_dir)
    if not pdir:
        log_err("未找到离线包 payloads/ 目录。请确认已解压完整离线安装包，"
                "或用 --payload 指定路径。")
        return [i for i in ids]
    pid = plat_id()
    print(t("menu.offline_header") % (pid, pdir))

    agents = {a["id"]: a for a in load_registry()}
    selected_npm = [agents[aid] for aid in ids
                    if aid in agents and agents[aid].get("method") == "npm" and aid != "opencode"]
    # Bundled Node is the reproducible default and every selected Agent is checked individually below.
    strictest_node = ">=18"

    # 1) 离线包优先使用自带 Node，确保路径与版本可复现；无载荷时才回退系统 Node。
    offline_node = None
    if selected_npm:
        src_node = os.path.join(pdir, "node", pid)
        if os.path.isdir(src_node):
            os.makedirs(RUNTIME_DIR, exist_ok=True)
            dst_node = runtime_node_dir()
            if os.path.exists(dst_node):
                shutil.rmtree(dst_node, ignore_errors=True)
            log_info("部署内置 Node 运行时 …")
            shutil.copytree(src_node, dst_node)
            if node_ok(node_exe(), strictest_node):
                offline_node = node_exe()
                log_ok("内置 Node 就绪：%s" % node_exe())
            else:
                log_err("内置 Node 不满足所选 Agent 最低版本 %s" % strictest_node)
        else:
            system_node = shutil.which("node")
            if system_node and node_ok(system_node, strictest_node):
                offline_node = system_node
                log_ok("离线包无 Node 载荷，使用系统 Node：%s" % system_node)
            else:
                log_err("离线包未包含 %s Node，系统 Node 也不满足 %s" % (pid, strictest_node))

    # 2) Windows：部署内置 Python（供 ab 使用，若系统无可用 python）
    if not POSIX and not find_python():
        emb = os.path.join(pdir, "python", "win-embed.zip")
        if os.path.exists(emb):
            dst_py = os.path.join(RUNTIME_DIR, "python")
            os.makedirs(RUNTIME_DIR, exist_ok=True)
            import zipfile
            with zipfile.ZipFile(emb) as z:
                z.extractall(dst_py)
            log_ok("内置 Python 就绪：%s" % os.path.join(dst_py, "python.exe"))

    # 3) 逐个 Agent 落盘
    ok_list, fail_list = [], []
    for aid in ids:
        a = agents.get(aid)
        if not a:
            log_err("未知 Agent：%s" % aid)
            fail_list.append(aid)
            continue
        if aid == "coco":
            if not POSIX:
                log_err("CoCo Agent 官方仅支持 Linux/macOS，Windows 无法离线安装")
                fail_list.append(aid)
                continue
            plat_payload = os.path.join(pdir, "agents", "coco", pid)
            if not os.path.isdir(plat_payload):
                log_err("%s：离线包中没有 %s 平台的载荷" % (a["name"], pid))
                fail_list.append(aid)
                continue
            if coco_offline_install(a, plat_payload, preset=preset):
                record_install(a, "offline", os.path.join(shim_bin_dir(), "coco"))
                ok_list.append(aid)
            else:
                fail_list.append(aid)
            continue
        src = os.path.join(pdir, "agents", aid, pid, "node_modules")
        if not (a.get("method") == "npm" and os.path.isdir(src)):
            log_err(t("menu.offline_no_payload") % (a["name"], pid))
            fail_list.append(aid)
            continue
        if aid != "opencode" and (not offline_node or not node_ok(offline_node, a.get("node"))):
            log_err(t("menu.offline_no_node") % a["name"])
            fail_list.append(aid)
            continue
        dst = os.path.join(AGENTS_DIR, aid)
        candidate = dst + ".new.%s" % os.getpid()
        backup = dst + ".old.%s" % os.getpid()
        shutil.rmtree(candidate, ignore_errors=True)
        shutil.rmtree(backup, ignore_errors=True)
        os.makedirs(candidate, exist_ok=True)
        candidate_nm = os.path.join(candidate, "node_modules")
        log_info(t("menu.offline_deploying") % (a["name"], dir_size_mb(src)))
        if POSIX:
            shutil.copytree(src, candidate_nm)
        else:
            # Windows：载荷可能含超长路径，robocopy 原生支持（exit<8 均为成功）
            r = subprocess.run(["robocopy", src, candidate_nm, "/E", "/NFL", "/NDL", "/NJH", "/NJS"],
                               capture_output=True)
            if r.returncode >= 8:
                log_err("robocopy 部署失败（code=%d）：%s" % (r.returncode, aid))
                shutil.rmtree(candidate, ignore_errors=True)
                fail_list.append(aid)
                continue
        if os.path.isdir(dst): os.replace(dst, backup)
        os.replace(candidate, dst)
        dst_nm = os.path.join(dst, "node_modules")
        if aid == "hermes":
            try:
                fixup_hermes_venv(os.path.join(pdir, "agents", "hermes", pid), dst_nm)
            except Exception as error:
                log_err("Hermes 路径修复失败：%s" % error)
                shutil.rmtree(dst, ignore_errors=True)
                if os.path.isdir(backup): os.replace(backup, dst)
                fail_list.append(aid)
                continue
        entry_override = None
        if aid == "opencode":
            entry_override = select_opencode_binary(a, dst, pid)
            if not entry_override:
                log_err("OpenCode 离线载荷没有可运行的官方平台 binary")
                shutil.rmtree(dst, ignore_errors=True)
                if os.path.isdir(backup): os.replace(backup, dst)
                fail_list.append(aid)
                continue
        # 原版安装（默认）：不写任何模型配置、不注入环境变量
        env_extra, args_prefix = wire_agnes(a) if preset else ({}, [])
        shim = write_shim(a, env_extra, args_prefix, node_path=offline_node,
                          entry_override=entry_override)
        if shim:
            shutil.rmtree(backup, ignore_errors=True)
            record_install(a, "offline", os.path.join(
                shim_bin_dir(), a["bin"] + ("" if POSIX else ".cmd")))
            log_ok(t("menu.offline_ok") % (a["name"], a["bin"]))
            ok_list.append(aid)
        else:
            shutil.rmtree(dst, ignore_errors=True)
            if os.path.isdir(backup): os.replace(backup, dst)
            fail_list.append(aid)
        for note in a.get("notes", []) or []:
            print("  ℹ %s" % note)
    ensure_path_registered()
    print("\n" + t("menu.install_summary") %
          (", ".join(ok_list) or "-", ", ".join(fail_list) or "-"))
    if not POSIX:
        print(t("menu.install_hint_win"))
    return fail_list


def dir_size_mb(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total / 1048576.0


def _npm_package_name_from_spec(spec):
    spec = str(spec or "")
    if spec.startswith("@"):
        slash = spec.find("/")
        version = spec.find("@", slash + 1)
        return spec[:version] if version >= 0 else spec
    return spec.split("@", 1)[0]


def offline_npm_entry(a):
    """Resolve the real npm package bin entry; .bin copies are not relocatable."""
    package_name = _npm_package_name_from_spec(a.get("npm"))
    if not package_name:
        return None
    package_dir = os.path.join(AGENTS_DIR, a["id"], "node_modules", *package_name.split("/"))
    metadata_path = os.path.join(package_dir, "package.json")
    try:
        with open(metadata_path, "r", encoding="utf-8") as source:
            metadata = json.load(source)
        bins = metadata.get("bin")
        if isinstance(bins, str):
            relative = bins
        elif isinstance(bins, dict):
            relative = bins.get(a.get("bin"))
            if not relative and len(bins) == 1:
                relative = next(iter(bins.values()))
        else:
            relative = None
        entry = os.path.normpath(os.path.join(package_dir, relative)) if relative else None
        return entry if entry and _inside(entry, package_dir) and os.path.isfile(entry) else None
    except (OSError, ValueError, TypeError):
        return None


def opencode_binary_candidates(a, root, platform_id):
    """Return pinned official OpenCode native binaries bundled for one target."""
    result = []
    binary = "opencode.exe" if platform_id.startswith("win-") else "opencode"
    npm_package = a.get("npm") or ""
    for package in (a.get("offline_binary_packages") or {}).get(platform_id, []):
        for base in (os.path.join(root, "node_modules", npm_package, "node_modules"),
                     os.path.join(root, "node_modules")):
            path = os.path.join(base, package, "bin", binary)
            if os.path.isfile(path) and os.path.getsize(path) > 10 * 1024 * 1024:
                result.append(path)
                break
    return result


def select_opencode_binary(a, root, platform_id):
    """Select regular/AVX2 or baseline binary by executing the official version probe."""
    for candidate in opencode_binary_candidates(a, root, platform_id):
        try:
            result = subprocess.run([candidate, "--version"], stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, timeout=20)
            if result.returncode == 0:
                return candidate
        except (OSError, subprocess.TimeoutExpired):
            continue
    return None


def _npm_entry_kind(entry):
    extension = os.path.splitext(entry)[1].lower()
    if extension in (".js", ".mjs", ".cjs"):
        return "node"
    try:
        with open(entry, "rb") as source:
            first = source.readline(256).lower()
        if first.startswith(b"#!") and b"node" in first:
            return "node"
    except OSError:
        pass
    if extension in (".cmd", ".bat"):
        return "cmd"
    return "direct"


def write_shim(a, env_extra=None, args_prefix=None, node_path=None, entry_override=None):
    """为离线安装的 Agent 生成启动 shim。"""
    aid, bin_ = a["id"], a["bin"]
    env_extra = env_extra or {}
    args_prefix = args_prefix or []
    node_path = node_path or node_exe()
    try:
        if POSIX:
            bin_dir = shim_bin_dir()
            if not _ensure_bin_dir(bin_dir):
                raise ValueError("无法创建 shim 目录：%s" % bin_dir)
            path = os.path.join(bin_dir, bin_)
            if a.get("special_install") == "hermes":
                venv_py = os.path.join(AGENTS_DIR, "hermes", "node_modules", "hermes-agent",
                                       "runtime", "hermes-agent", "venv", "bin", "python")
                runpy = os.path.join(AGENTS_DIR, "hermes", "hermes-run.py")
                body = 'exec "%s" "%s" "$@"\n' % (venv_py, runpy)
            else:
                lines = _agnes_env_posix_lines(env_extra)
                nd = runtime_node_dir()
                if os.path.isdir(nd):
                    lines.append('[ -x "%s/bin/node" ] && export PATH="%s/bin:$PATH"' % (nd, nd))
                entry = entry_override or offline_npm_entry(a)
                if not entry:
                    raise ValueError("未找到 %s 的真实 npm bin 入口" % aid)
                pre = " ".join('"%s"' % x for x in args_prefix)
                if _npm_entry_kind(entry) == "node":
                    lines.append('exec "%s" "%s"%s "$@"' %
                                 (node_path, entry, (" " + pre) if pre else ""))
                else:
                    lines.append('exec "%s"%s "$@"' % (entry, (" " + pre) if pre else ""))
                body = "\n".join(lines) + "\n"
            shim_text = "#!/bin/sh\n# AgentBoot shim for %s\nAB_ROOT=\"$HOME/.agentboot\"\n%s" % (aid, body)
            if not _write_executable(path, shim_text):
                raise ValueError("无法写入 shim：%s" % path)
        else:
            bin_dir = shim_bin_dir()
            os.makedirs(bin_dir, exist_ok=True)
            path = os.path.join(bin_dir, bin_ + ".cmd")
            if a.get("special_install") == "hermes":
                venv_py = os.path.join(AGENTS_DIR, "hermes", "node_modules", "hermes-agent",
                                       "runtime", "hermes-agent", "venv", "Scripts", "python.exe")
                runpy = os.path.join(AGENTS_DIR, "hermes", "hermes-run.py")
                body = '"%s" "%s" %%*\r\n' % (venv_py, runpy)
            else:
                lines = ["rem AgentBoot shim"]
                lines += _agnes_env_cmd_lines(env_extra)
                entry = entry_override or offline_npm_entry(a)
                if not entry:
                    raise ValueError("未找到 %s 的真实 npm bin 入口" % aid)
                pre = " ".join(args_prefix)
                kind = _npm_entry_kind(entry)
                if kind == "node":
                    lines.append('"%s" "%s"%s %%*' %
                                 (node_path, entry, (" " + pre) if pre else ""))
                elif kind == "cmd":
                    lines.append('call "%s"%s %%*' % (entry, (" " + pre) if pre else ""))
                else:
                    lines.append('"%s"%s %%*' % (entry, (" " + pre) if pre else ""))
                body = "\r\n".join(lines) + "\r\n"
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                f.write("@echo off\r\nrem AgentBoot shim for %s\r\n"
                        'set "AB_ROOT=%%USERPROFILE%%\\.agentboot"\r\n'
                        'if exist "%%AB_ROOT%%\\runtime\\node-win-x64\\node.exe" '
                        'set "PATH=%%AB_ROOT%%\\runtime\\node-win-x64;%%PATH%%"\r\n%s' % (aid, body))
        return True
    except Exception as e:
        log_err("写入 shim 失败：%s" % e)
        return False


def _broadcast_windows_env_change():
    """广播 WM_SETTINGCHANGE，让资源管理器立即重载用户环境变量。

    注册表写入本身不会通知已运行的进程；不广播的话，新开的终端要等到
    注销/切换用户后才看得到新 PATH（用户可感知的“装完不能用”）。
    """
    try:
        import ctypes
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        result = ctypes.c_ulong()
        ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST, WM_SETTINGCHANGE, 0,
            "Environment", SMTO_ABORTIFHUNG, 5000, ctypes.byref(result))
    except Exception:
        pass


def ensure_path_registered():
    """把 AgentBoot 相关目录加入用户 PATH（幂等）。

    AGENTBOOT_NO_ENV_WRITE=1 时整体跳过：基准测试/自动化用临时 AB_HOME
    跑安装流程时，不应把临时目录写进用户真实的 PATH（注册表 / shell rc）。"""
    if os.environ.get("AGENTBOOT_NO_ENV_WRITE", "").strip() == "1":
        return
    targets = shim_bin_dirs() + prefix_bin_dirs()
    if POSIX:
        block_begin = "# >>> agentboot >>>"
        block_end = "# <<< agentboot <<<"
        npm_bin = os.path.join(NPM_PREFIX, "bin")
        block = "\n".join([block_begin,
                           '# AgentBoot 添加的 PATH',
                           'for _d in "$HOME/.agentboot/bin" "$HOME/.local/bin" "%s"; do' % npm_bin,
                           '  [ -d "$_d" ] && case ":$PATH:" in *":$_d:"*) ;; *) export PATH="$_d:$PATH";; esac',
                           'done',
                           'unset _d',
                           block_end, ""])
        for rc in [os.path.expanduser("~/.bashrc"), os.path.expanduser("~/.profile"),
                   os.path.expanduser("~/.zshrc")]:
            try:
                content = ""
                if os.path.exists(rc):
                    with open(rc, "r", encoding="utf-8") as f:
                        content = f.read()
                if block_begin in content and block_end in content:
                    before, rest = content.split(block_begin, 1)
                    _old, after = rest.split(block_end, 1)
                    updated = before.rstrip("\n") + "\n" + block + after.lstrip("\n")
                    with open(rc, "w", encoding="utf-8") as f:
                        f.write(updated)
                else:
                    with open(rc, "a", encoding="utf-8") as f:
                        f.write("\n" + block)
            except Exception:
                pass
    else:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE)
            try:
                cur, typ = winreg.QueryValueEx(key, "Path")
            except FileNotFoundError:
                cur, typ = "", winreg.REG_EXPAND_SZ
            parts = [p for p in cur.split(";") if p]
            changed = False
            for t in targets:
                t = os.path.normpath(t)
                if t.lower() not in [p.lower() for p in parts]:
                    parts.insert(0, t)
                    changed = True
            if changed:
                winreg.SetValueEx(key, "Path", 0, typ, ";".join(parts))
            winreg.CloseKey(key)
            os.environ["PATH"] = ";".join(targets + [os.environ.get("PATH", "")])
            if changed:
                _broadcast_windows_env_change()
        except Exception as e:
            log_err("更新用户 PATH 失败：%s（可手动把 %s 加入 PATH）" % (e, os.path.join(AB_HOME, "bin")))


# ---------------------------------------------------------------- 镜像与代理

def npm_current_registry():
    try:
        r = subprocess.run([npm_cmd() or "npm", "config", "get", "registry"],
                           capture_output=True, text=True, timeout=20, env=child_env())
        return r.stdout.strip()
    except Exception:
        return "?"


def set_npm_registry(url):
    if not npm_cmd():
        log_err("npm 不可用（先安装 Node 或让菜单下载运行时）")
        return
    subprocess.run([npm_cmd(), "config", "set", "registry", url], env=child_env())
    log_ok("npm registry 已设为 %s" % url)


def set_proxy(url=None):
    from urllib.parse import urlsplit
    data = load_env_json()
    if url:
        parsed = urlsplit(url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            log_err("代理地址必须是有效的 http:// 或 https:// URL")
            return False
        data["proxy"] = url
        save_env_json(data)
        os.environ["HTTP_PROXY"] = url
        os.environ["HTTPS_PROXY"] = url
        if npm_cmd():
            subprocess.run([npm_cmd(), "config", "set", "proxy", url], env=child_env(), capture_output=True)
            subprocess.run([npm_cmd(), "config", "set", "https-proxy", url], env=child_env(), capture_output=True)
        write_env_scripts(url)
        log_ok("代理已保存：%s" % url)
        print("  也可在 shell 中执行：")
        if POSIX:
            print('    export HTTP_PROXY=%s HTTPS_PROXY=%s' % (url, url))
        else:
            print('    setx HTTP_PROXY %s' % url)
        return True
    else:
        data.pop("proxy", None)
        save_env_json(data)
        os.environ.pop("HTTP_PROXY", None)
        os.environ.pop("HTTPS_PROXY", None)
        if npm_cmd():
            subprocess.run([npm_cmd(), "config", "delete", "proxy"], env=child_env(), capture_output=True)
            subprocess.run([npm_cmd(), "config", "delete", "https-proxy"], env=child_env(), capture_output=True)
        try:
            os.remove(os.path.join(AB_HOME, "env.sh"))
            os.remove(os.path.join(AB_HOME, "env.ps1"))
        except OSError:
            pass
        log_ok("代理已清除")
        return True


def write_env_scripts(url):
    with open(os.path.join(AB_HOME, "env.sh"), "w", encoding="utf-8", newline="\n") as f:
        f.write("export HTTP_PROXY=%s\nexport HTTPS_PROXY=%s\n" % (url, url))
    with open(os.path.join(AB_HOME, "env.ps1"), "w", encoding="utf-8") as f:
        f.write("$env:HTTP_PROXY='%s'\n$env:HTTPS_PROXY='%s'\n" % (url, url))


def mirror_status():
    from urllib.parse import urlsplit
    cn = cn_mode()
    print(t("menu.mirror_net") % (t("menu.mirror_cn") if cn else t("menu.mirror_global")))
    print(t("menu.mirror_npm") % npm_current_registry())
    npm_hosts = ["registry.npmjs.org"] + [urlsplit(url).hostname for _, url in NPM_MIRRORS]
    probes = agent.probe_hosts(tuple(npm_hosts), timeout=1.5)
    fixed = (load_env_json().get("npm_registry") or "").strip()
    for label, url in NPM_MIRRORS:
        mark = "✓" if probes.get(urlsplit(url).hostname) else "✗"
        cur = t("menu.current_mark") if fixed == url else ""
        print("  [%s] %s %s%s" % (mark, label, url, cur))
    mark = "✓" if probes.get("registry.npmjs.org") else "✗"
    cur = t("menu.current_mark") if fixed == NPM_OFFICIAL else ""
    print("  [%s] %s %s%s" % (mark, t("menu.mirror_npm_official_label"), NPM_OFFICIAL, cur))
    gh_fixed = (load_env_json().get("gh_proxy") or "").strip()
    gh_order = gh_mirrors()
    gh_hosts = tuple(urlsplit(p).hostname for _, p in GH_PROXIES)
    ghp = agent.probe_hosts(gh_hosts, timeout=1.5)
    for label, p in GH_PROXIES:
        mark = "✓" if ghp.get(urlsplit(p).hostname) else "✗"
        cur = t("menu.current_mark") if gh_fixed == p or (gh_order and gh_order[0] == p) else ""
        print("  [%s] %s %s%s" % (mark, label, p, cur))
    mode = "直连（已关闭加速）" if gh_fixed.lower() in ("off", "direct", "none") else \
        ("固定 %s" % gh_fixed if gh_fixed else "自动探测（国内加速 / 全球直连）")
    print("  GitHub 加速: %s" % mode)
    env = load_env_json()
    print(t("menu.mirror_proxy") % (env.get("proxy") or os.environ.get("HTTPS_PROXY") or "-"))
    print(t("menu.mirror_switch") % (os.environ.get("AGENTBOOT_MIRROR") or "auto"))


# ---------------------------------------------------------------- 环境体检

def doctor():
    print("AgentBoot 环境体检 v%s · 平台 %s" % (VERSION, plat_id()))
    print("-" * 52)
    # find_python 带 python_ok 真实执行校验：Windows 上 which("python3") 命中的
    # 常是商店存根（打印"未找到 Python"却存在），直接展示会误导
    py = find_python()
    print("Python : %s" % (py or "未安装（Windows 会自动用内置运行时）"))
    node = shutil.which("node") or (node_exe() if os.path.exists(node_exe()) else None)
    print("Node   : %s" % (node or "未安装（安装 Agent 时会自动下载 v22 运行时）"))
    print("npm    : %s" % (npm_cmd() or "未安装"))
    print("git    : %s" % (shutil.which("git") or "未安装（可选）"))
    print("curl   : %s" % (shutil.which("curl") or "未安装（可选）"))
    print("-" * 52)
    mirror_status()
    print("-" * 52)
    try:
        agents = load_registry()
        print("可安装 Agent（%d 个）：" % len(agents))
        for a in agents:
            status = detect_install(a)
            mark = {"managed": "已安装（AgentBoot 管理）", "legacy": "已安装（旧版残留）",
                    "external": "已安装（外部安装，AgentBoot 不管理）"}.get(
                status["status"], "未安装")
            print("  %-14s %-22s [%s]" % (a["id"], a["name"], mark))
    except Exception as e:
        log_err("读取 Agent 注册表失败：%s" % e)
    pdir = find_payload_dir()
    print("离线载荷     : %s" % (pdir or "未找到（离线安装功能需解压完整离线包）"))
    print("-" * 52)
    agent.doctor(agent.load_config())


# ---------------------------------------------------------------- 交互菜单

def pick_agents(agents, title, allow_custom=False):
    print("\n%s" % title)
    om, nm = t("menu.offline_mark"), t("menu.online_mark")
    for i, a in enumerate(agents, 1):
        offline_mark = om if a.get("offline") else nm
        mark = " ★" if a.get("custom") else ""
        print("  [%2d] %-16s %-24s (%s) %s%s" % (i, a["id"], a["name"], offline_mark, a.get("desc", ""), mark))
    extra = "  [ a] %s · [ 0] %s" % (t("menu.pick_all_a"), t("menu.pick_back"))
    if allow_custom:
        extra += t("menu.pick_custom")
    print(extra)
    raw = input(t("menu.pick_prompt")).strip().lower()
    if not raw or raw == "0":
        return []
    if raw == "+":
        nid = custom_add_wizard()
        return [nid] if nid else []
    if raw == "a":
        return [a["id"] for a in agents if a.get("method") == "npm"]
    ids = []
    for tok in re.split(r"[\s,，]+", raw):
        if tok.isdigit() and 1 <= int(tok) <= len(agents):
            ids.append(agents[int(tok) - 1]["id"])
        elif tok in [a["id"] for a in agents]:
            ids.append(tok)
    if not ids:
        print(t("menu.pick_none"))   # 无效输入要有反馈，不能静默跳回上级
    return sorted(set(ids), key=lambda x: [a["id"] for a in agents].index(x))


def pick_installed_agents(agents):
    """只显示能证明由 AgentBoot 管理的安装，防止误卸载同名系统命令。"""
    candidates = []
    print("\n%s" % t("menu.uninstall_title"))
    for a in agents:
        status = detect_install(a)
        if status["managed"]:
            candidates.append(a)
            print("  [%2d] %-16s %-24s (%s)" %
                  (len(candidates), a["id"], a["name"], status.get("source") or "legacy"))
    if not candidates:
        print(t("menu.uninstall_empty"))
        return []
    print("  [ 0] %s" % t("menu.pick_back"))
    raw = input(t("menu.pick_prompt")).strip().lower()
    if not raw or raw == "0":
        return []
    ids = []
    known = [a["id"] for a in candidates]
    for tok in re.split(r"[\s,，]+", raw):
        if tok.isdigit() and 1 <= int(tok) <= len(candidates):
            ids.append(candidates[int(tok) - 1]["id"])
        elif tok in known:
            ids.append(tok)
    return sorted(set(ids), key=known.index)


def pick_versions(ids):
    """安装前逐个询问版本（回车=最新）。返回 {agent_id: version}。

    只对 npm 类 Agent 询问；版本列表拉取失败时只提示「默认最新」，
    用户仍可手动输入版本号。
    """
    by_id = {a["id"]: a for a in load_registry()}
    npm_agents = [aid for aid in ids if by_id.get(aid, {}).get("npm")]
    if not npm_agents:
        return {}
    print("\n" + t("menu.pick_versions_title"))
    chosen = {}
    for aid in npm_agents:
        found = agent_npm_versions(by_id[aid])
        hint = (" · ".join(found[:6])) if found else t("menu.pick_version_latest")
        raw = input("  %s [%s] %s" % (aid, hint, t("menu.pick_version_prompt"))).strip()
        if raw:
            chosen[aid] = raw.lstrip("v")
    return chosen


def menu_model(cfg):
    """模型配置：ab 提供商管理器 + 安装第三方 Agent 时的预置开关。"""
    agent.choose_model(cfg)
    print("")
    print(t("menu.preset_title"))
    state = t("menu.preset_on") if preset_model_enabled() else t("menu.preset_off")
    print("  " + t("menu.preset_state") % state)
    print("  [1] " + t("menu.preset_enable"))
    print("  [2] " + t("menu.preset_disable"))
    print("  [0] " + t("menu.pick_back"))
    c = input(t("menu.pick")).strip()
    if c == "1":
        set_preset_model(True)
    elif c == "2":
        set_preset_model(False)


# ---------------------------------------------------------------- 自定义离线包构建

BUILD_PLATFORMS = [
    ("linux-x64", "Linux x64（Intel/AMD 服务器、桌面）"),
    ("linux-arm64", "Linux arm64（ARM 服务器、国产化设备）"),
    ("win-x64", "Windows 10/11 x64"),
    ("darwin-x64", "macOS Intel"),
    ("darwin-arm64", "macOS Apple Silicon (M 系列)"),
]


def pick_platforms():
    """多选目标平台，返回平台 id 列表。空输入 = 常用三平台。"""
    print("\n" + t("menu.build_pick_platforms"))
    for i, (pid, desc) in enumerate(BUILD_PLATFORMS, 1):
        print("  [%d] %-14s %s" % (i, pid, desc))
    raw = input("平台编号: ").strip().lower()
    if not raw:
        return [plat_id()]
    ids = []
    for tok in re.split(r"[\s,，]+", raw):
        if tok.isdigit() and 1 <= int(tok) <= len(BUILD_PLATFORMS):
            ids.append(BUILD_PLATFORMS[int(tok) - 1][0])
        elif tok in [p[0] for p in BUILD_PLATFORMS]:
            ids.append(tok)
    if not ids:
        log_err("未识别任何平台，使用当前平台")
        return [plat_id()]
    return sorted(set(ids), key=lambda x: [p[0] for p in BUILD_PLATFORMS].index(x))


def pick_offline_agents():
    """多选要打进离线包的 Agent（默认全选支持离线的）。返回 id 列表。"""
    capable = [a for a in load_registry() if a.get("offline")]
    print("\n" + t("menu.pick_offline_agents"))
    for i, a in enumerate(capable, 1):
        print("  [%2d] %-14s %-22s %s" % (i, a["id"], a["name"], a.get("desc", "")))
    print(t("menu.build_aider_hint"))
    raw = input(t("menu.pick_prompt")).strip().lower()
    if raw == "a" or not raw:
        return [a["id"] for a in capable]
    ids = []
    for tok in re.split(r"[\s,，]+", raw):
        if tok.isdigit() and 1 <= int(tok) <= len(capable):
            ids.append(capable[int(tok) - 1]["id"])
        elif tok in [a["id"] for a in capable]:
            ids.append(tok)
    return sorted(set(ids), key=lambda x: [a["id"] for a in capable].index(x))


def build_offline_run(platforms, agents_ids):
    """调用 scripts/build-offline.* 构建自定义离线包（跨平台分发到对应脚本）。"""
    if not platforms or not agents_ids:
        log_err(t("menu.build_empty"))
        return False
    log_info(t("menu.build_start") % (",".join(platforms), ",".join(agents_ids)))
    print(t("menu.build_wait") + "\n")
    env = child_env()
    tag = "v" + VERSION
    if POSIX:
        script = os.path.join(APP_DIR, "scripts", "build-offline.sh")
        env.update({"PLATFORMS": ",".join(platforms), "AGENTS": ",".join(agents_ids), "TAG": tag})
        cmd = ["sh", script]
    else:
        script = os.path.join(APP_DIR, "scripts", "build-offline.ps1")
        cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script,
               "-Tag", tag, "-Platforms", ",".join(platforms), "-Agents", ",".join(agents_ids)]
    code = run_with_timeout(cmd, env=env, timeout=BUILD_TIMEOUT, label="离线构建 ")
    ok = code == 0
    if ok:
        dist = os.path.join(APP_DIR, "dist")
        print("")
        log_ok(t("menu.build_done") % dist)
        try:
            for fn in sorted(os.listdir(dist)):
                if fn.startswith("AgentBoot-offline-%s-" % tag):
                    p = os.path.join(dist, fn)
                    if os.path.isfile(p):
                        print("  %-52s %8.1f MB" % (fn, os.path.getsize(p) / 1048576.0))
        except OSError:
            pass
    else:
        log_err(t("menu.build_fail") % r.returncode)
    return ok


def build_offline_wizard():
    platforms = pick_platforms()
    agents_ids = pick_offline_agents()
    if not agents_ids:
        log_err(t("menu.build_empty"))
        return
    print("\n" + t("menu.build_plan") % (", ".join(platforms), ", ".join(agents_ids)))
    if input(t("menu.build_confirm_yn")).strip().lower() in ("n", "no"):
        return
    print(t("menu.build_wait"))
    build_offline_run(platforms, agents_ids)


# ---------------------------------------------------------------- Agnes 预配置（安装即用）

def wire_agnes(a):
    """安装成功后按 Agent 类型预置 Agnes 免费模型。
    返回需要注入启动 shim 的环境变量 dict（config 文件类已直接落盘）。"""
    aid = a["id"]
    home = os.path.expanduser("~")
    agnes = agent.PRESETS["agnes"]
    base, key, model = agnes["base_url"], agnes["api_key"], agnes["model"]

    if aid == "codex":
        d = os.path.join(home, ".codex")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "config.toml")
        block = ('\n# >>> AgentBoot 预置 Agnes 免费模型 >>>\n'
                 'model = "agnes-2.5-flash"\n'
                 'model_provider = "agnes"\n\n'
                 '[model_providers.agnes]\n'
                 'name = "Agnes"\n'
                 'base_url = "https://apihub.agnes-ai.com/v1"\n'
                 'env_key = "AGNES_API_KEY"\n'
                 'wire_api = "chat"\n'
                 '# <<< AgentBoot <<<\n')
        if not os.path.exists(p):
            with open(p, "w", encoding="utf-8", newline="\n") as f:
                f.write(block)
        else:
            cur = open(p, "r", encoding="utf-8").read()
            if "model_providers.agnes" not in cur:
                with open(p, "a", encoding="utf-8", newline="\n") as f:
                    f.write(block)
        log_ok("已预置 Agnes 免费模型（~/.codex/config.toml）")
        return {"AGNES_API_KEY": key}, []

    if aid == "qwen-code":
        log_ok("已预置 Agnes 免费模型（OPENAI_* 环境变量随 shim 注入）")
        return {"OPENAI_API_KEY": key, "OPENAI_BASE_URL": base, "OPENAI_MODEL": model}, []

    if aid == "aider":
        log_ok("已预置 Agnes 免费模型（shim 自动追加 --model openai/agnes-2.5-flash）")
        return {"OPENAI_API_KEY": key, "OPENAI_API_BASE": base}, ["--model", "openai/" + model]

    if aid == "opencode":
        d = os.path.join(home, ".config", "opencode")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "opencode.json")
        cfg = {
            "$schema": "https://opencode.ai/config.json",
            "provider": {
                "agnes": {
                    "npm": "@ai-sdk/openai-compatible",
                    "name": "Agnes",
                    "options": {"baseURL": base, "apiKey": key},
                    "models": {model: {"name": "Agnes 2.5 Flash (free)"}}}},
            "model": "agnes/" + model}
        if not os.path.exists(p):
            with open(p, "w", encoding="utf-8", newline="\n") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
            log_ok("已预置 Agnes 免费模型（~/.config/opencode/opencode.json）")
        return {}, []

    return {}, []  # claude-code/gemini-cli 等官方协议登录类，不强行接线


def _agnes_env_cmd_lines(env_extra):
    return ['set "%s=%s"' % (k, v) for k, v in env_extra.items()]


def _agnes_env_posix_lines(env_extra):
    return ['export %s="%s"' % (k, v) for k, v in env_extra.items()]


def write_online_shim(a, found, env_extra, args_prefix=None):
    """在线安装后写包装 shim（注入 Agnes 环境变量并转发到真实命令）。"""
    bin_ = a["bin"]
    args_prefix = args_prefix or []
    if any(_inside(found, d) for d in shim_bin_dirs()):
        log_err("拒绝写入 shim：解析目标 %s 是 AgentBoot 自己的 shim，"
                "会形成 exec 死循环" % found)
        return False
    bin_dir = shim_bin_dir()
    if not _ensure_bin_dir(bin_dir):
        log_err("无法创建 shim 目录：%s" % bin_dir)
        return False
    try:
        if POSIX:
            p = os.path.join(bin_dir, bin_)
            lines = ["#!/bin/sh", "# AgentBoot wrapper"]
            lines += _agnes_env_posix_lines(env_extra or {})
            pre = " ".join('"%s"' % x for x in args_prefix)
            lines.append('exec "%s"%s "$@"' % (found, (" " + pre) if pre else ""))
            if not _write_executable(p, "\n".join(lines) + "\n"):
                raise OSError("无法写入 %s" % p)
        else:
            p = os.path.join(bin_dir, bin_ + ".cmd")
            lines = ["@echo off", "rem AgentBoot wrapper"]
            lines += _agnes_env_cmd_lines(env_extra or {})
            pre = " ".join(args_prefix)
            lines.append('"%s"%s %%*' % (found, (" " + pre) if pre else ""))
            with open(p, "w", encoding="utf-8-sig", newline="") as f:
                f.write("\r\n".join(lines) + "\r\n")
        return True
    except Exception as e:
        log_err("写入包装 shim 失败：%s" % e)
        return False


def menu_mirror():
    while True:
        print("\n" + t("menu.mirror_title"))
        mirror_status()
        print(" [1] " + t("menu.mirror_pick_npm"))
        print(" [2] " + t("menu.mirror_pick_gh"))
        print(" [3] " + t("menu.mirror_pick_mode"))
        print(" [4] " + t("menu.mirror_proxy_set"))
        print(" [5] " + t("menu.mirror_proxy_clear"))
        print(" [0] " + t("menu.pick_back"))
        c = input(t("menu.pick")).strip()
        if c == "1":
            fixed = (load_env_json().get("npm_registry") or "").strip()
            print("\n" + t("menu.mirror_pick_npm"))
            options = list(NPM_MIRRORS) + [(t("menu.mirror_npm_official_label"), NPM_OFFICIAL)]
            for i, (label, url) in enumerate(options, 1):
                cur = t("menu.current_mark") if fixed == url else ""
                print("  [%d] %s %s%s" % (i, label, url, cur))
            print("  [a] " + t("menu.mirror_npm_auto"))
            raw = input(t("menu.pick")).strip().lower()
            if raw == "a":
                set_npm_mirror(None)
            elif raw.isdigit() and 1 <= int(raw) <= len(options):
                set_npm_mirror(options[int(raw) - 1][1])
        elif c == "2":
            fixed = (load_env_json().get("gh_proxy") or "").strip()
            print("\n" + t("menu.mirror_pick_gh"))
            print("  [a] " + t("menu.mirror_gh_auto"))
            for i, (label, url) in enumerate(GH_PROXIES, 1):
                cur = t("menu.current_mark") if fixed == url else ""
                print("  [%d] %s %s%s" % (i, label, url, cur))
            print("  [d] " + t("menu.mirror_gh_off"))
            raw = input(t("menu.pick")).strip().lower()
            if raw == "a":
                set_gh_proxy("auto")
            elif raw == "d":
                set_gh_proxy("off")
            elif raw.isdigit() and 1 <= int(raw) <= len(GH_PROXIES):
                set_gh_proxy(GH_PROXIES[int(raw) - 1][1])
        elif c == "3":
            current = _mirror_mode_pref() or "auto"
            print("\n" + t("menu.mirror_pick_mode"))
            print("  [a] " + t("menu.mirror_mode_auto") + (t("menu.current_mark") if current == "auto" else ""))
            print("  [c] " + t("menu.mirror_mode_cn") + (t("menu.current_mark") if current == "cn" else ""))
            print("  [d] " + t("menu.mirror_mode_off") + (t("menu.current_mark") if current == "off" else ""))
            raw = input(t("menu.pick")).strip().lower()
            if raw == "a":
                set_mirror_mode("auto")
            elif raw == "c":
                set_mirror_mode("cn")
            elif raw == "d":
                set_mirror_mode("off")
        elif c == "4":
            url = input(t("menu.proxy_addr")).strip()
            if url:
                set_proxy(url)
        elif c == "5":
            set_proxy(None)
        else:
            return


def resolve_lang():
    """语言解析：环境变量 AGENTBOOT_LANG 优先，其次配置文件，默认中文。"""
    cfg = agent.load_config()
    lang = os.environ.get("AGENTBOOT_LANG") or cfg.get("lang") or "zh"
    i18n.set_lang(lang)
    return cfg


def set_lang_persist(lang, cfg=None):
    lang = "en" if str(lang or "").lower().startswith("en") else "zh"
    i18n.set_lang(lang)
    cfg = cfg if isinstance(cfg, dict) else agent.load_config()
    cfg["lang"] = lang
    agent.save_config(cfg)
    if lang == "en":
        log_ok(i18n.t("menu.lang_saved_en"))
    else:
        log_ok(i18n.t("menu.lang_saved"))


def lang_switch(cfg):
    print(i18n.t("menu.lang_title"))
    print(i18n.t("menu.lang_pick"))
    c = input(i18n.t("menu.pick")).strip()
    set_lang_persist("en" if c == "2" else "zh", cfg)


def banner():
    print(r"""
    _                    _   ____              _
   / \   __ _  ___ _ __ | |_| __ )  ___   ___ | |_
  / _ \ / _` |/ _ \ '_ \| __|  _ \ / _ \ / _ \| __|
 / ___ \ (_| |  __/ | | | |_| |_) | (_) | (_) | |_
/_/   \_\__, |\___|_| |_|\__|____/ \___/ \___/ \__|
        |___/   AgentBoot Console v%s
""" % VERSION)
    print(i18n.t("menu.tagline") + "\n")


def main_menu(cfg=None):
    cfg = cfg if isinstance(cfg, dict) else resolve_lang()
    agents = load_registry()
    while True:
        banner()
        print("  [1] %s" % t("menu.m1"))
        print("  [2] %s" % t("menu.m2"))
        print("  [3] %s" % t("menu.m3"))
        print("  [4] %s" % t("menu.m4"))
        print("  [5] %s" % t("menu.m5"))
        print("  [6] %s" % t("menu.m6"))
        print("  [7] %s" % t("menu.m7"))
        print("  [8] %s" % t("menu.m8"))
        print("  [9] %s" % t("menu.m9"))
        print("  [0] %s" % t("menu.bye"))
        c = input("\n" + t("menu.pick")).strip()
        if c == "1":
            doctor()
            input(t("menu.enter_back"))
        elif c == "2":
            ids = pick_agents(agents, t("menu.pick2_title"), allow_custom=True)
            if ids:
                versions = pick_versions(ids)
                install_online(ids, versions=versions)
                input(t("menu.enter_back"))
        elif c == "3":
            ids = pick_agents([a for a in agents if a.get("offline")], t("menu.pick3_title"))
            if ids:
                offline_install(ids)
                input(t("menu.enter_back"))
        elif c == "4":
            menu_model(cfg)
        elif c == "5":
            menu_mirror()
            input(t("menu.enter_back"))
        elif c == "6":
            agent.repl(cfg)
        elif c == "7":
            build_offline_wizard()
        elif c == "8":
            lang_switch(cfg)
        elif c == "9":
            ids = pick_installed_agents(agents)
            if ids:
                if input(t("menu.uninstall_confirm") % ", ".join(ids)).strip().lower() in ("y", "yes"):
                    uninstall_agents(ids)
                input(t("menu.enter_back"))
        elif c == "0":
            print(t("menu.bye"))
            return


def main():
    agent._utf8_console()
    argv = sys.argv[1:]
    if argv and argv[0] in ("version", "--version"):
        print("AgentBoot 控制台 v%s" % VERSION)
        return
    cfg = resolve_lang()
    if not argv:
        try:
            main_menu(cfg)
        except EOFError:
            print(t("menu.bye"))
        return
    cmd = argv[0]
    if cmd == "lang":
        set_lang_persist(argv[1] if len(argv) > 1 else "zh")
        return
    if cmd == "doctor":
        doctor()
    elif cmd == "install":
        preset = _preset_flag(argv[1:])
        raw_tokens = [t for t in re.split(r"[,\s]+", " ".join(argv[1:]))
                      if t and not t.startswith("-")]
        ids = [t.split("@", 1)[0] if "@" in t and not t.startswith("@") else t
               for t in raw_tokens]
        versions = parse_agent_version_tokens(raw_tokens)
        # --version X：单 agent 时生效，多 agent 时报错（避免误指定）
        if "--version" in argv:
            vi = argv.index("--version")
            want = argv[vi + 1] if vi + 1 < len(argv) else ""
            if len(ids) == 1 and want:
                versions[ids[0]] = want
            elif want:
                log_err("--version 只能配合单个 Agent；多 agent 请用 <id>@<version> 记号")
                raise SystemExit(2)
        if ids:
            preset_status_line()
            failures = install_online(ids, preset=preset, versions=versions)
            if failures:
                raise SystemExit(1)
        else:
            print("用法: menu.py install [--preset|--no-preset] [<id>[@<版本>] ...]")
            print("示例: menu.py install opencode@1.19.5 codex@0.90.0")
            print("      menu.py install opencode --version 1.19.5")
            print("查询可用版本: menu.py versions <id>")
    elif cmd == "versions":
        if len(argv) < 2:
            print("用法: menu.py versions <agent-id>")
            raise SystemExit(2)
        lookup = {a["id"]: a for a in load_registry()}
        target = lookup.get(argv[1])
        if not target:
            log_err("未知 Agent：%s" % argv[1])
            raise SystemExit(1)
        spec = target.get("npm") or ""
        print("%s（%s）" % (target["name"], spec or target.get("method")))
        if not spec:
            print("  该 Agent 不走 npm，无版本列表。")
        else:
            found = agent_npm_versions(target)
            if not found:
                log_err("拉取版本列表失败（网络问题）；默认始终安装最新版。")
            else:
                print("  最近稳定版本（最新在前，安装时默认最新，可用 <id>@<版本> 指定）：")
                for v in found:
                    print("    %s%s" % (v, "  ← 最新" if v == found[0] else ""))
    elif cmd == "offline":
        payload = None
        if "--payload" in argv:
            i = argv.index("--payload")
            payload = argv[i + 1] if i + 1 < len(argv) else None
            rest = argv[1:i] + argv[i + 2:]
        else:
            rest = argv[1:]
        ids = [t for t in re.split(r"[,\s]+", " ".join(rest)) if t and not t.startswith("-")]
        if ids:
            preset_status_line()
            failures = offline_install(ids, payload, preset=_preset_flag(argv[1:]))
            if failures:
                raise SystemExit(1)
        else:
            print("用法: menu.py offline [--preset|--no-preset] claude-code --payload <dir>")
    elif cmd in ("uninstall", "remove"):
        purge = "--purge" in argv
        rest = [arg for arg in argv[1:] if arg != "--purge"]
        ids = [tok for tok in re.split(r"[,\s]+", " ".join(rest)) if tok]
        if ids:
            failures = uninstall_agents(ids, purge=purge)
            if failures:
                raise SystemExit(1)
        else:
            print(t("menu.uninstall_usage"))
    elif cmd == "mirror":
        arg = argv[1] if len(argv) > 1 else "auto"
        if arg == "auto":
            set_mirror_mode("auto")
            mirror_status()
        elif arg == "cn":
            set_mirror_mode("cn")
            set_npm_registry(npm_registry(True))
        elif arg == "off":
            set_mirror_mode("off")
            mirror_status()
        elif arg == "npm":
            set_npm_mirror(argv[2] if len(argv) > 2 else None)
        elif arg == "gh":
            set_gh_proxy(argv[2] if len(argv) > 2 else "auto")
        elif arg == "proxy":
            set_proxy(argv[2] if len(argv) > 2 else None)
        else:
            print("用法: menu.py mirror auto|cn|off|npm [源URL]|gh [auto|off|前缀URL]|proxy [url]")
    elif cmd == "preset":
        arg = argv[1].strip().lower() if len(argv) > 1 else ""
        if arg in ("on", "1", "true", "yes", "开", "启用"):
            set_preset_model(True)
        elif arg in ("off", "0", "false", "no", "关", "关闭"):
            set_preset_model(False)
        elif arg == "":
            state = "开" if preset_model_enabled() else "关（原版安装，默认）"
            print("安装 Agent 时预置 Agnes 免费模型：当前 [%s]" % state)
            print("  agentboot preset on   开启预置（安装即写好模型配置）")
            print("  agentboot preset off  关闭预置（默认，Agent 保持原版）")
            print("一次性覆盖：agentboot install <id> --preset / --no-preset")
        else:
            print("用法: menu.py preset [on|off]")
    elif cmd == "add-agent":
        # 用法：
        #   add-agent --list
        #   add-agent --del <id>
        #   add-agent <id> npm <包名> [bin]
        #   add-agent <id> pip <包名> [bin]
        #   add-agent <id> script <URL> <bin>
        arg = argv[1] if len(argv) > 1 else ""
        if arg in ("--list", "list"):
            items = load_custom_agents()
            print("自定义 Agent（%d 个）：%s" % (len(items), os.path.join(AB_HOME, "custom-agents.json")))
            for a in items:
                print("  %-16s %-10s %-32s bin=%s" % (a.get("id"), a.get("method"), a.get("npm") or a.get("pip") or a.get("script"), a.get("bin")))
        elif arg in ("--del", "del", "remove"):
            if len(argv) < 3:
                print("用法: add-agent --del <id>")
                raise SystemExit(2)
            custom_remove_entry(argv[2])
            log_ok("已删除自定义 Agent：%s" % argv[2])
        elif len(argv) >= 4 and argv[2] in ("npm", "pip", "script"):
            aid, m, pkg = argv[1], argv[2], argv[3]
            entry = {"id": aid, "name": aid, "desc": "自定义 Agent", "bin": argv[4] if len(argv) > 4 else aid,
                     "method": m, "requires": [], "notes": ["用户自定义条目"]}
            if not _valid_agent_id(entry["id"]) or not _valid_bin_name(entry["bin"]):
                log_err("id 与命令名只能包含字母、数字、点、下划线与连字符")
                raise SystemExit(2)
            if m == "npm":
                entry["npm"] = pkg
            elif m == "pip":
                entry["pip"] = pkg
            else:
                entry["script"] = pkg
            try:
                custom_add_entry(entry)
            except ValueError as error:
                log_err(str(error))
                raise SystemExit(2)
            log_ok("已添加自定义 Agent：%s（%s）" % (aid, pkg))
        else:
            print(__doc__)
    elif cmd == "build-offline":
        # 用法：build-offline <平台列表> <Agent列表>（逗号分隔），无参数进入向导
        if len(argv) >= 3:
            plats = [t for t in re.split(r"[,\s]+", argv[1]) if t]
            ids = [t for t in re.split(r"[,\s]+", argv[2]) if t]
            if not build_offline_run(plats, ids):
                raise SystemExit(1)
        else:
            build_offline_wizard()
    elif cmd == "menu":
        main_menu(cfg)
    else:
        print(__doc__)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n（已退出）")
    except EOFError:
        print("\n（输入已结束，已退出）")
